from pathlib import Path
from datetime import datetime
from zoneinfo import ZoneInfo
import hashlib,json,os,re,shutil,sys,tempfile
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'tools'))
import package_mod
def read(name):return json.loads((ROOT/'outputs'/name).read_text())
def write(path,data):path.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
check=read('0.5.12-release-selfcheck.json')
assert check['success'] and not check['failures'] and not check['warnings'],check
audit=read('0.5.12-release-all.json');rows=audit['rows']
assert audit.get('completed_at') and len(rows)==1162 and not any(r['errors'] for r in rows)
assert all(hashlib.sha256((ROOT/'mod/Tractor/scripts'/k).read_bytes()).hexdigest()==v for k,v in audit['source_sha256'].items())
spatial=read('0.5.12-release-spatial.json');assert spatial['complete']
web_log=(ROOT/'outputs/0.5.12-release-web-tests.log').read_text();assert 'Ran 10 tests' in web_log and web_log.rstrip().endswith('OK')
manifest=package_mod.build_archive(package_mod.MOD,package_mod.ARCHIVE)
assert package_mod.verify_archive(package_mod.MOD,package_mod.ARCHIVE)==manifest
digest=hashlib.sha256(package_mod.ARCHIVE.read_bytes()).hexdigest()
target=Path.home()/"Library/Application Support/Steam/steamapps/common/Don't Starve Together/dontstarve_steam.app/Contents/mods/Tractor"
now=datetime.now(ZoneInfo('Asia/Shanghai'));backup=ROOT/'outputs/game-mod-backups'/now.strftime('%Y%m%d-%H%M%S-%f')/'Tractor'
backup.parent.mkdir(parents=True)
previous=re.search(r'^version\s*=\s*"([^"]+)"',(target/'modinfo.lua').read_text(),re.M).group(1)
stage=Path(tempfile.mkdtemp(prefix='.tractor-0.5.12-',dir=target.parent))
try:
 for name,p in package_mod.source_files(package_mod.MOD).items():
  q=stage/name;q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,q)
 write(stage/'INSTALL-MANIFEST.json',manifest)
 assert all(hashlib.sha256((stage/k).read_bytes()).hexdigest()==v['sha256'] for k,v in manifest['files'].items())
 target.rename(backup)
 try:stage.rename(target)
 except BaseException:backup.rename(target);raise
finally:
 if stage.exists():shutil.rmtree(stage)
assert all((target/name).read_bytes()==p.read_bytes() for name,p in package_mod.source_files(package_mod.MOD).items())
assert json.loads((target/'INSTALL-MANIFEST.json').read_text())==manifest
install={'installed_at':now.isoformat(),'version':'0.5.12','previous_version':previous,'target':str(target),'backup':str(backup),'stable_0.5.11_backup':str(ROOT/'outputs/game-mod-backups/20261115-001608-476600/Tractor'),'archive_sha256':digest,'source_files':len(manifest['files']),'all_installed_bytes_match':True,'installed_manifest_matches':True,'zip_crc':True,'game_restarted':False,'save_files_modified':False,'pushed':False}
package={'archive':'Tractor.zip','version':'0.5.12','source_files':len(manifest['files']),'sha256':digest,'zip_crc':True,'all_source_bytes_match':True}
sys.path.insert(0,str(ROOT/'web/giant-seed-verifier'));import runner
source=runner.manifest();assert source['installed_match']
old={r['id']:r for name in ('structured','holdout','symmetry','large') for r in read('0.5.12-final-'+name+'.json')['rows']}
improved=[{'id':r['id'],'before':old[r['id']]['count'],'after':r['count']} for r in rows if r['count']>old[r['id']]['count']]
assert all(r['count']>=old[r['id']]['count'] for r in rows)
better=[r for r in spatial['rows'] if r['better_valid_witness']]
summary={'version':'0.5.12','completed_at':now.isoformat(),'priority':['season, stock, spacing, density, per-plant family, per-tile nutrient net zero; two-species 4+4 center gap','maximum found plant count','family fragmentation then nearest-three distance','tidiness'],'source':source,'scene_count':len(rows),'suites':{k:sum(r['suite']==k for r in rows) for k in ('structured','holdout','symmetry','large')},'season_counts':{k:sum(r['season']==k for r in rows) for k in ('autumn','winter','spring','summer')},'constraint_failures':0,'composition_upper_met':sum(r['count']==r['upper'] for r in rows),'zero_upper_cases':sum(r['upper']==0 for r in rows),'below_relaxed_upper':sum(r['count']<r['upper'] for r in rows),'spatial_optimum_additionally_proved':sum(r['spatial_optimum_met'] for r in spatial['rows']),'known_better_valid_witnesses':better,'quantity_improvements_since_first_pass':improved,'quantity_regressions_since_first_pass':0,'selfcheck':check,'web_tests':{'run':10,'failures':0,'point_parity_scenarios':76},'scope_limits':['Finite heuristic search; known quantity gaps are explicitly listed. No claim of universal quantity or arrangement optimality.','Independent spatial MILP is development-only and never feeds a layout to the Mod or webpage.','Offline adapters do not replace DST client, growth or multiplayer acceptance.'],'reproduce':['PYTHONPATH=/tmp/pylua python3 tools/seed_strategy_audit.py --suite all --jobs 4 --output outputs/0.5.12-release-all.json','PYTHONPATH=/tmp/pylua python3 tools/balanced_gap_audit.py --source outputs/0.5.12-release-all.json --output outputs/0.5.12-release-spatial.json','PYTHONPATH=/tmp/pylua python3 tools/selfcheck.py --release --report outputs/0.5.12-release-selfcheck.json','PYTHONPATH=/tmp/pylua python3 -m unittest discover -s web/giant-seed-verifier/tests -v']}
for name,data in [('seed-audit-validation',summary),('selfcheck-validation',check),('game-install-validation',install),('install-validation',package)]:
 write(ROOT/'docs/evidence'/('0.5.12-'+name+'.json'),data)
 write(ROOT/'outputs'/('0.5.12-'+name+'.json'),data)
print(json.dumps({'installed_files':len(manifest['files']),'scenes':len(rows),'upper_met':summary['composition_upper_met'],'known_gaps':len(better),'behavior':check['checks'][-1]['details'],'web_installed_match':source['installed_match']},ensure_ascii=False))
