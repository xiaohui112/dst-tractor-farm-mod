import itertools,time,sys
sys.path.insert(0,'tools')
from seed_strategy_audit import SHAPES

def pack(shape,blanks):
 pts=[(tx*3+x,tz*3+z) for tx,tz in SHAPES[shape] for z in range(3) for x in range(3)]
 n=len(pts);nb=[]
 for x,z in pts:nb.append(sum(1<<j for j,(xx,zz) in enumerate(pts) if (x-xx)**2+(z-zz)**2<=9))
 nodes=0;failed=set();start=time.perf_counter()
 def dfs(mask,b):
  nonlocal nodes
  nodes+=1
  if nodes%10000==0 and time.perf_counter()-start>10:raise TimeoutError
  if bin(mask).count('1')==b:return []
  if (mask,b) in failed:return None
  active=[i for i in range(n) if mask>>i&1]
  p=min(active,key=lambda i:bin(mask&nb[i]).count('1'))
  if bin(mask&nb[p]).count('1')<4:
   if b:return dfs(mask^(1<<p),b-1)
   return None
  near=[i for i in active if i!=p and nb[p]>>i&1]
  candidates=[]
  for a,c,d in itertools.combinations(near,3):
   if nb[a]>>c&1 and nb[a]>>d&1 and nb[c]>>d&1:
    group=[p,a,c,d];bits=sum(1<<i for i in group)
    if any(bin(nb[i]&(mask^bits)).count('1')<4 for i in active if not bits>>i&1) and not b:continue
    score=sum((pts[i][0]-pts[j][0])**2+(pts[i][1]-pts[j][1])**2 for i in group for j in group)
    candidates.append((score,group,bits))
  for _,group,bits in sorted(candidates):
   result=dfs(mask^bits,b)
   if result is not None:return [group]+result
  if b:
   result=dfs(mask^(1<<p),b-1)
   if result is not None:return result
  failed.add((mask,b));return None
 try:
  result=dfs((1<<n)-1,blanks);print(shape,blanks,'nodes',nodes,'elapsed',time.perf_counter()-start,'groups',len(result) if result else None)
 except TimeoutError:print(shape,blanks,'timeout',nodes)
for shape,b in [('T-4',0),('S-4',0),('U-5',1),('plus-5',1)]:pack(shape,b)
