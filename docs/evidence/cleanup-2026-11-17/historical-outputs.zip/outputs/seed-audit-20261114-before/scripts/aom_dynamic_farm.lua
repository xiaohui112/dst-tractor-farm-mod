-- Dynamic server-side nine-pit plans. Native definitions; no nutrient-net constraint.
local M={MAX_TILES=64}
local Registry=require('aom_farm_registry')
local Seed=require('aom_seed_strategy')
local Layout=require('aom_seed_layout')
local function Key(x,z)return string.format('%.3f:%.3f',x,z)end
local function Number(x)return type(x)=='number' and x==x and math.abs(x)<1000000 end
local function Defs()return require('prefabs/farm_plant_defs').PLANT_DEFS end
local function Yield()if M._yield then M._yield() end end
function M.Scan(tile,expected)
 local map=TheWorld.Map
 if map:GetTileAtPoint(tile.x,0,tile.z)~=WORLD_TILES.FARMING_SOIL or not map:IsPassableAtPoint(tile.x,0,tile.z) then return nil,'NEED_PLOW' end
 local out={}
 for _,v in ipairs(map:GetEntitiesOnTileAtPoint(tile.x,0,tile.z)) do if v:IsValid() and not v:HasTag('NOCLICK') and not v:HasTag('INLIMBO') then
  local soil=v.prefab=='farm_soil' and v:HasTag('soil')
  local crop=type(v.prefab)=='string' and string.match(v.prefab,'^farm_plant_(.+)$')
  if soil or crop then
   local x,_,z=v.Transform:GetWorldPosition();local found
   for s=1,9 do local px,pz=tile.x+((s-1)%3-1)*4/3,tile.z+(math.floor((s-1)/3)-1)*4/3;if (px-x)^2+(pz-z)^2<=.16 then found=s;break end end
   if not found or out[found] then return nil,'FOREIGN_CROP' end
   if not soil and (not expected or expected[found]~=crop or v.weed_def or v:HasTag('deadplant') or v.components.health and v.components.health:IsDead() or require('aom_crop_state').IsRotten(v)) then return nil,'FOREIGN_CROP' end
   out[found]={x=x,z=z,cx=tile.x,cz=tile.z,crop=crop or false,soil=soil}
  elseif v:HasTag('farm_plant') or v:HasTag('weed') or v.prefab=='farm_soil_debris' or (not v:HasTag('NOBLOCK') and not v:HasTag('aom_attachment') and not v:HasTag('player') and not v:HasTag('FX') and (v:HasTag('structure') or v:HasTag('wall') or v:HasTag('tree') or v:HasTag('boulder'))) then return nil,'FOREIGN_CROP' end
 end end
 for s=1,9 do if not out[s] then return nil,'NEED_PLOW' end end
 return out
end
function M.Validate(b)
 if type(b)~='table' or b.dynamic~=true or type(b.tiles)~='table' or #b.tiles<1 or #b.tiles>M.MAX_TILES or type(b.slots)~='table' or #b.slots~=#b.tiles*9 then return false end
 local defs=Defs();local seen={};local total=0
 local spacing=GetFarmTillSpacing and GetFarmTillSpacing() or 1.25
 for ti,t in ipairs(b.tiles) do
  if type(t)~='table' or not Number(t.x) or not Number(t.z) or seen[Key(t.x,t.z)] then return false end
  seen[Key(t.x,t.z)]=true
  local planted=0
  for s=1,9 do local p=b.slots[(ti-1)*9+s]
   if type(p)~='table' or not Number(p.x) or not Number(p.z) or p.cx~=t.x or p.cz~=t.z then return false end
   local x,z=t.x+((s-1)%3-1)*4/3,t.z+(math.floor((s-1)/3)-1)*4/3
   if (p.x-x)^2+(p.z-z)^2>.16 then return false end
   if p.crop then planted=planted+1 end
   if p.crop and (not defs[p.crop] or not defs[p.crop].good_seasons or not defs[p.crop].good_seasons[b.season]) then return false end
  end
  if planted>(TUNING.FARM_PANT_OVERCROWDING_MAX_PLANTS or 10) then return false end
 end
 for i,p in ipairs(b.slots) do if p.crop then
  total=total+1;local family=0;local d=defs[p.crop]
  for j,q in ipairs(b.slots) do if q.crop then local dd=(p.x-q.x)^2+(p.z-q.z)^2
   if i~=j and dd<=spacing^2 then return false end
   if p.crop==q.crop and dd<=(d.family_check_dist or 4)^2 then family=family+1 end
  end end
  if family<(d.family_min_count or 4) then return false end
 end end
 return total>0,total
end
local function Solve(tiles,slots,counts,season)
 local defs=Defs();local crops=Layout.Crops(counts,defs,season)
 local _,upper,kindsupper=Layout.Allocate(crops,counts,defs,#slots,0,Yield)
 if upper==0 then return nil,'MISSING_SEEDS' end
 local near={};local maxradius=16
 for _,k in ipairs(crops) do maxradius=math.max(maxradius,(defs[k].family_check_dist or 4)^2) end
 for i,p in ipairs(slots) do near[i]={};for j,q in ipairs(slots) do local d=(p.x-q.x)^2+(p.z-q.z)^2;if d<=maxradius then near[i][#near[i]+1]={j,d} end end;if i%9==0 then Yield() end end
 local function Score(a)
  local bad,cost=0,0
  for i,k in ipairs(a) do if k then
   local n=0;local ds={};local radius=(defs[k].family_check_dist or 4)^2
   for _,q in ipairs(near[i]) do if q[2]<=radius and a[q[1]]==k then n=n+1;ds[#ds+1]=q[2] end end
   bad=bad+math.max(0,(defs[k].family_min_count or 4)-n);table.sort(ds);for j=2,math.min(4,#ds) do cost=cost+ds[j] end
  end end
  for ti=1,#tiles do
   local offset=(ti-1)*9
   for axis=1,2 do for line=0,2 do
    local first=offset+(axis==1 and line*3+1 or line+1)
    local stride=axis==1 and 1 or 3
    if a[first] and a[first]==a[first+stride] and a[first]==a[first+stride*2] then cost=cost-12 end
   end end
  end
  return bad,cost
 end
 local geometry=Layout.Geometry(tiles,slots,defs,Yield)
 local function Repair(a,active,seed)
  local state=seed;local bad,cost=Score(a)
  local function Rand()state=state*16807%2147483647;return state%active+1 end
  for step=1,160 do
   if bad==0 then break end
   local i,j=Rand(),Rand()
   if a[i]~=a[j] then
    a[i],a[j]=a[j],a[i];local nb,nc=Score(a)
    if nb<bad or nb==bad and nc<=cost or step%37==0 then bad,cost=nb,nc else a[i],a[j]=a[j],a[i] end
   end
   Yield()
  end
  return a
 end
 local best,bestn,bestkinds,besttiles,bestcost=nil,0,0,math.huge,math.huge
 local function Accept(a)
  if not Layout.Valid(a,geometry) then return end
  local n,kinds,seen=0,0,{}
  for _,k in ipairs(a) do if k then n=n+1;if not seen[k] then seen[k]=true;kinds=kinds+1 end end end
  if n<bestn or n==bestn and kinds<bestkinds then return end
  local usedtiles=0
  for t=1,#tiles do for s=1,9 do if a[(t-1)*9+s] then usedtiles=usedtiles+1;break end end end
  if n==bestn and kinds==bestkinds and usedtiles>besttiles then return end
  local cost=Layout.Metrics(a,geometry).score
  if n>bestn or kinds>bestkinds or usedtiles<besttiles or cost<bestcost then best,bestn,bestkinds,besttiles,bestcost=a,n,kinds,usedtiles,cost end
 end
 -- 先尝试整片数量分配及逐地皮行列布局，达到种类上界前不能被单作物提前截断。
 for offset=0,math.min(#crops-1,3) do
  local allocation=Layout.Allocate(crops,counts,defs,#slots,offset,Yield)
  for r=0,15 do
   Accept(Layout.Distributed(allocation,tiles,r%8,r>=8));Yield()
   if bestn==upper and bestkinds==kindsupper then break end
  end
  if bestn~=upper or bestkinds~=kindsupper then
   for axis=1,2 do
    local candidate,active=Layout.Clustered(allocation,slots,axis)
    if active<#slots and active<=36 then candidate=Repair(candidate,active,17+axis+offset*31) end
    Accept(candidate);Yield()
   end
  end
  if bestn==upper and bestkinds==kindsupper then break end
 end
 table.sort(crops,function(a,b)if counts[a]~=counts[b] then return counts[a]>counts[b] end return a<b end)
 local state=17;local budget=600
 local function Rand(n)state=state*16807%2147483647;return state%n+1 end
 for attempt=1,math.max(4,math.min(12,#crops*4)) do
  if bestn==upper and bestkinds==kindsupper then break end
  local order={};for i=1,#slots do order[i]=i end
  table.sort(order,function(i,j)local p,q=slots[i],slots[j];local x,y=attempt%2==0 and p.x or p.z,attempt%2==0 and q.x or q.z;if x~=y then return x<y end return (attempt%2==0 and p.z or p.x)<(attempt%2==0 and q.z or q.x) end)
  local a={};for i=1,#slots do a[i]=false end
  local allocation,used={},0
  for c=1,#crops do
   local k=crops[(c+math.floor((attempt-1)/2)-1)%#crops+1]
   local n=math.min(counts[k],#slots-used);local minimum=defs[k].family_min_count or 4
   if n>0 and n<minimum then
    local missing=minimum-n
    if counts[k]>=minimum then
     for j=#allocation,1,-1 do local old=allocation[j];local spare=old.n-(defs[old.k].family_min_count or 4)
      local take=math.min(spare,missing);old.n=old.n-take;used=used-take;missing=missing-take;if missing==0 then break end
     end
     n=math.min(counts[k],#slots-used)
    end
   end
   if n>=minimum then allocation[#allocation+1]={k=k,n=n};used=used+n end
  end
  local pos=1
  for _,item in ipairs(allocation) do for _=1,item.n do a[order[pos]]=item.k;pos=pos+1 end end
  local bad,cost=Score(a)
  for step=1,120 do
   if bad==0 or budget<=0 then break end
   budget=budget-1
   local i,j=Rand(#slots),Rand(#slots)
   if a[i]~=a[j] then a[i],a[j]=a[j],a[i];local nb,nc=Score(a)
    if nb<bad or nb==bad and nc<=cost or step%37==0 then bad,cost=nb,nc else a[i],a[j]=a[j],a[i] end
   end
   Yield()
  end
  if bad>0 then
   local changed=true
   while changed do changed=false;local remove={}
    for i,k in ipairs(a) do if k then local n=0;for _,q in ipairs(near[i]) do if a[q[1]]==k and q[2]<=(defs[k].family_check_dist or 4)^2 then n=n+1 end end;if n<(defs[k].family_min_count or 4) then remove[k]=true end end end
    for i,k in ipairs(a) do if remove[k] then a[i]=false;changed=true end end
   end
   bad,cost=Score(a)
  end
  if bad==0 then Accept(a) end
  Yield()
  if bestn==upper and bestkinds==kindsupper then break end
 end

 if not best or bestn==0 then return nil,'MISSING_SEEDS' end
 local arrangement
 best,arrangement=Layout.Regularize(best,geometry,Yield)
 for i,k in ipairs(best) do slots[i].crop=k;slots[i].index=i end
 local b={dynamic=true,version=4,season=season,tiles=tiles,slots=slots,completed={},done=0,total=bestn,
  upper=upper,optimal=bestn==upper,confirmed=true,automatic=true,arrangement=arrangement}
 if not M.Validate(b) then return nil,'NO_FAMILY' end
 return b
end
function M.Build(inst,cx,cz)
 -- 索引是缓存，重启后仍按真实九宫格恢复连通范围；无效地皮不作为桥梁。
 local queue={{x=cx,z=cz}};local seen={[Key(cx,cz)]=true};local usable,slots={},{}
 local i=1
 while i<=#queue do
  local tile=queue[i];i=i+1
  local points,why=M.Scan(tile)
  if points then
   if #usable>=M.MAX_TILES then return nil,'FARM_TOO_LARGE' end
   usable[#usable+1]=tile;Registry.Record(TheWorld,tile.x,tile.z)
   for _,p in ipairs(points) do slots[#slots+1]=p end
   for _,offset in ipairs({{0,-4},{-4,0},{4,0},{0,4}}) do
    local x,z=tile.x+offset[1],tile.z+offset[2];local key=Key(x,z)
    if not seen[key] then seen[key]=true;queue[#queue+1]={x=x,z=z} end
   end
  elseif tile.x==cx and tile.z==cz then return nil,why end
  Yield()
 end
 return Solve(usable,slots,inst.components.aom_attachment_store:CountSeedsByCrop(Seed.GetCropOfSeedItem),TheWorld.state.season)
end
function M.Targets(inst,cx,cz)
 local b=inst._block
 if b.season~=TheWorld.state.season then return nil,'SEASON_CHANGED' end
 local counts=inst.components.aom_attachment_store:CountSeedsByCrop(Seed.GetCropOfSeedItem)
 local remaining,targets={},{};local done=0
 for ti,tile in ipairs(b.tiles) do
  local expected={};for s=1,9 do expected[s]=b.slots[(ti-1)*9+s].crop end
  local points,reason=M.Scan(tile,expected);if not points then return nil,reason end
  for s,p in ipairs(points) do local i=(ti-1)*9+s;local plan=b.slots[i]
   if (p.x-plan.x)^2+(p.z-plan.z)^2>.04 then return nil,'NO_FAMILY' end
   if plan.crop then
    if not p.soil then b.completed[i]=true elseif b.completed[i] then return nil,'PLANT_MISSING' end
    if b.completed[i] then done=done+1 else remaining[plan.crop]=(remaining[plan.crop] or 0)+1;if tile.x==cx and tile.z==cz then targets[#targets+1]=plan end end
   end
  end
 end
 b.done=done
 for k,n in pairs(remaining) do if (counts[k] or 0)<n then return nil,'MISSING_SEEDS' end end
 if #targets==0 then return nil,done==b.total and 'COMPLETE' or 'NEXT_TILE' end
 return targets
end
function M.Start(inst,cx,cz)
 local co=coroutine.create(function()return M.Build(inst,cx,cz)end);inst._aom_dynamic_job=co
 local function Tick()
  if inst._aom_dynamic_job~=co then return end
  if inst.IsValid and not inst:IsValid() or inst._attachment_type~='seeder' or inst._seed_strategy~='GIANT' or not inst._working then inst._aom_dynamic_job=nil;return end
  M._yield=coroutine.yield
  local ok,b,why
  for _=1,4 do
   ok,b,why=coroutine.resume(co)
   if not ok or coroutine.status(co)=='dead' then break end
  end
  M._yield=nil
  if not ok then inst._aom_dynamic_error=tostring(b);b=nil;why='FAILED' end
  if not ok or coroutine.status(co)=='dead' then
   inst._aom_dynamic_job=nil
   if b then inst._block=b;inst._aom_plan_outdated=nil else inst._aom_dynamic_reason=why end
   if inst._working then local x,_,z=inst.Transform:GetWorldPosition();x,_,z=TheWorld.Map:GetTileCenterPoint(x,0,z);require('aom_drive').WorkTile(inst,x,z) end
  else inst:DoTaskInTime(FRAMES or 1/30,Tick) end
 end
 inst:DoTaskInTime(FRAMES or 1/30,Tick)
end
return M
