-- 坐标计划：逐株验证季节、间距和家族；播种不读取地皮养分。
local AOMBlock = {}
local Locale=require("aom_locale")
local L=Locale.Text
local BLOCKS = require("aom_giant_layouts")
local Farm = require("aom_farm_work")
local BY_ID = {}
local CROP_CN = {carrot="胡萝卜",corn="玉米",potato="土豆",tomato="番茄",asparagus="芦笋",eggplant="茄子",pumpkin="南瓜",watermelon="西瓜",dragonfruit="火龙果",durian="榴莲",garlic="大蒜",onion="洋葱",pepper="辣椒",pomegranate="石榴"}
local VERSION = 3
local MATCH_DIST_SQ = .04
local function Key(x,z) return string.format("%.3f:%.3f",x,z) end
local function ValidNumber(v) return type(v)=="number" and v==v and math.abs(v)<1000000 end
local function Near(a,b) return (a.x-b.x)^2+(a.z-b.z)^2<=MATCH_DIST_SQ end
function AOMBlock.GetCropName(crop) return L(CROP_CN[crop] or crop) end
function AOMBlock.BuildName(ratio)
    local parts={}
    for crop,n in pairs(ratio) do parts[#parts+1]=AOMBlock.GetCropName(crop)..n end
    table.sort(parts)
    return table.concat(parts," ")
end
for _,list in pairs(BLOCKS) do
    for _,combo in ipairs(list) do
        combo.name=AOMBlock.BuildName(combo.ratio);combo.total=0
        for _,n in pairs(combo.ratio) do combo.total=combo.total+n end
        BY_ID[combo.id]=combo
    end
    table.sort(list,function(a,b)
        if a.total~=b.total then return a.total<b.total end
        return a.id<b.id
    end)
end
AOMBlock.BLOCKS=BLOCKS

-- 按当前游戏实际作物定义验证季节、坑距与家族。
function AOMBlock.ValidateCombo(combo,season)
    if not combo or combo.reference_only or not combo.slots then return false,"NO_LAYOUT" end
    local defs=require("prefabs/farm_plant_defs").PLANT_DEFS
    local tiles,counts,exempt={},{},{}
    local spacing=GetFarmTillSpacing and GetFarmTillSpacing() or TUNING.FARM_TILL_SPACING or 1.25
    local points={}
    for _,crop in ipairs(combo.not_giant or {}) do exempt[crop]=true end
    for _,slot in ipairs(combo.slots) do
        if not ValidNumber(slot.x) or not ValidNumber(slot.z) or math.abs(slot.x)>=2 or math.abs(slot.z)>=2 then return false,"INVALID_LAYOUT" end
        if slot.crop then
            local def=defs[slot.crop]
            if not def or not def.good_seasons or not def.good_seasons[season] then return false,"WRONG_SEASON" end
            counts[slot.crop]=(counts[slot.crop] or 0)+1
            local k=Key(slot.tx,slot.tz)
            local tile=tiles[k] or {count=0}
            tiles[k]=tile;tile.count=tile.count+1
            if tile.count>(TUNING.FARM_PANT_OVERCROWDING_MAX_PLANTS or 10) then return false,"OVERCROWDED" end
            for _,p in ipairs(points) do
                if ((p.tx-slot.tx)*4+p.x-slot.x)^2+((p.tz-slot.tz)*4+p.z-slot.z)^2<=spacing*spacing+.000001 then
                    return false,"MOUNDS_TOO_CLOSE"
                end
            end
            points[#points+1]=slot

        end
    end
    for crop,n in pairs(combo.ratio) do if counts[crop]~=n then return false,"INVALID_COUNTS" end end
    for crop in pairs(counts) do if not combo.ratio[crop] then return false,"INVALID_COUNTS" end end
    for _,p in ipairs(combo.slots) do
        if p.crop and not exempt[p.crop] then
            local def=defs[p.crop]
            local radius=def.family_check_dist or 4
            local family=0
            for _,q in ipairs(combo.slots) do
                if p.crop==q.crop and ((p.tx-q.tx)*4+p.x-q.x)^2+((p.tz-q.tz)*4+p.z-q.z)^2<=radius^2 then family=family+1 end
            end
            if family<(def.family_min_count or 4) then return false,"NO_FAMILY" end
        end
    end
    return true
end
local function Remaining(block,combo)
    local counts={}
    for i,p in ipairs(combo.slots) do
        if p.crop and not block.completed[i] then counts[p.crop]=(counts[p.crop] or 0)+1 end
    end
    return counts
end
local function HasSeeds(counts,needs)
    for crop,n in pairs(needs) do if (counts[crop] or 0)<n then return false end end
    return true
end
function AOMBlock.ChooseCombo(season,seed_counts)
    for _,combo in ipairs(BLOCKS[season] or {}) do
        if HasSeeds(seed_counts,combo.ratio) and AOMBlock.ValidateCombo(combo,season) then return combo end
    end
end
local function Rotate(x,z,r)
    if r==1 then return -z,x elseif r==2 then return -x,-z elseif r==3 then return z,-x end
    return x,z
end
function AOMBlock.WorldSlots(block)
    if block.dynamic then
        local tiles={};for _,t in ipairs(block.tiles) do tiles[Key(t.x,t.z)]={x=t.x,z=t.z} end
        return block.slots,tiles
    end
    local combo=BY_ID[block.combo_id]
    local slots,tiles={},{}
    for i,p in ipairs(combo.slots) do
        local dx,dz=Rotate(p.tx*4,p.tz*4,block.rotation)
        local ox,oz=Rotate(p.x,p.z,block.rotation)
        local cx,cz=block.x+dx,block.z+dz
        local pos=block.positions and block.positions[i]
        slots[i]={x=pos and pos.x or cx+ox,z=pos and pos.z or cz+oz,cx=cx,cz=cz,crop=p.crop,index=i}
        tiles[Key(cx,cz)]={x=cx,z=cz}
    end
    return slots,tiles
end
local function CheckField(block,preparing,skip_occupied)
    local slots,tiles=AOMBlock.WorldSlots(block)
    local found={}
    for _,tile in pairs(tiles) do
        if not skip_occupied and not TheWorld.Map:IsPassableAtPoint(tile.x,0,tile.z) then return false,"INVALID_LAND" end
        if not preparing and TheWorld.Map:GetTileAtPoint(tile.x,0,tile.z)~=WORLD_TILES.FARMING_SOIL then return false,"NEED_PLOW" end
        for _,v in ipairs(TheWorld.Map:GetEntitiesOnTileAtPoint(tile.x,0,tile.z)) do
            local clearable=preparing and Farm.IsClearableDebris(v)
            if v:IsValid() and not clearable and (v:HasTag("farm_plant") or v:HasTag("weed") or v.prefab=="farm_soil_debris") then
                local x,_,z=v.Transform:GetWorldPosition()
                local matched=false
                for i,p in ipairs(slots) do
                    if p.crop and block.completed[i] and v.prefab=="farm_plant_"..p.crop and Near(p,{x=x,z=z}) then
                        if found[i] then return false,"FOREIGN_CROP" end
                        found[i]={x=x,z=z,crop=p.crop};matched=true;break
                    end
                end
                if not matched and not skip_occupied then return false,"FOREIGN_CROP" end
            end
        end
        if preparing and not skip_occupied then
            if TheWorld.Map:GetTileAtPoint(tile.x,0,tile.z)~=WORLD_TILES.FARMING_SOIL
                and TheWorld.Map.CanPlowAtPoint and not TheWorld.Map:CanPlowAtPoint(tile.x,0,tile.z) then return false,"INVALID_LAND" end
            local targets={}
            for _,p in ipairs(slots) do
                if p.crop and not block.completed[p.index] and p.cx==tile.x and p.cz==tile.z then targets[#targets+1]=p end
            end
            local clear,why=Farm.CheckProtected(tile.x,tile.z,nil,targets)
            if not clear then return false,why end
        end
    end
    for i in pairs(block.completed) do if not found[i] then return false,"PLANT_MISSING" end end
    return true,nil,found
end
local function NewBlock(combo,season,x,z,r)
    return {version=VERSION,combo_id=combo.id,season=season,x=x,z=z,rotation=r,confirmed=false,completed={},done=0}
end
function AOMBlock.ResetBlock(inst) inst._block=nil;inst._aom_plan_outdated=nil;inst._aom_dynamic_job=nil;inst._aom_dynamic_reason=nil end

-- 先检查整套余料及真实场地，再返回本格目标；调用方不得降级为顺序播种。
function AOMBlock.GetTargets(inst,season,seed_counts,cx,cz,preparing)
    if inst._aom_plan_outdated then return nil,"PLAN_OUTDATED" end
    -- 作业入口只消费明确确认的计划，不隐式创建或替换起点/方向/配比。
    if not inst._block then return nil,"PLAN_PENDING" end
    local block=inst._block
    if block.dynamic then return require("aom_dynamic_farm").Targets(inst,cx,cz) end
    local combo=BY_ID[block.combo_id]
    if block.confirmed~=true then return nil,"PLAN_PENDING" end
    -- 完成后保留坐标与进度；即使收获后全空，也必须显式重规划/确认下一轮。
    if block.done>=combo.total then return nil,"COMPLETE" end
    if block.season~=season then return nil,"SEASON_CHANGED" end
    local valid,reason=AOMBlock.ValidateCombo(combo,season)
    if not valid then return nil,reason end
    local slots,tiles=AOMBlock.WorldSlots(block)
    if not tiles[Key(cx,cz)] then return nil,"NEXT_TILE" end
    if not HasSeeds(seed_counts,Remaining(block,combo)) then return nil,"MISSING_SEEDS" end
    -- 实际开垦按当前地块/坑位跳过占用；预览、确认及播种仍严格检查整套计划。
    local field_ok,field_reason,positions=CheckField(block,preparing,preparing)
    if not field_ok then return nil,field_reason end
    -- 全部地块都准备好才开种，降低两边生长阶段相差过大的风险。
    if not preparing then
        for i,p in ipairs(slots) do
            if p.crop and not block.completed[i] then
                local soil=AOMBlock.FindSoilAt(p.x,p.z)
                if not soil then return nil,"NEED_PLOW" end
                local sx,_,sz=soil.Transform:GetWorldPosition()
                positions[i]={x=sx,z=sz,crop=p.crop}
            end
        end
    end
    -- 手工土坑可能略有偏移：还要检查实际坑位/已种作物，而不是只信任模板坐标。
    if not preparing then
        local defs=require("prefabs/farm_plant_defs").PLANT_DEFS
        local exempt={}
        for _,crop in ipairs(combo.not_giant) do exempt[crop]=true end
        for _,p in pairs(positions) do
            if not exempt[p.crop] then
                local family=0
                local def=defs[p.crop]
                for _,q in pairs(positions) do
                    if q.crop==p.crop and (p.x-q.x)^2+(p.z-q.z)^2<=(def.family_check_dist or 4)^2 then family=family+1 end
                end
                if family<(def.family_min_count or 4) then return nil,"NO_FAMILY" end
            end
        end
    end
    local targets={}
    for i,p in ipairs(slots) do
        if p.crop and not block.completed[i] and Key(p.cx,p.cz)==Key(cx,cz) then targets[#targets+1]=p end
    end
    if #targets==0 then return nil,"NEXT_TILE" end
    return targets
end
function AOMBlock.FindSoilAt(x,z)
    for _,v in ipairs(TheSim:FindEntities(x,0,z,.2,{"soil"},{"NOCLICK","INLIMBO"})) do
        if v.prefab=="farm_soil" and v:IsValid() then return v end
    end
end
function AOMBlock.RecordPlanted(inst,target)
    local block=inst._block
    if not block or not target or block.completed[target.index] then return false end
    local expected=AOMBlock.WorldSlots(block)[target.index]
    if not expected or expected.crop~=target.crop or not Near(expected,target) then return false end
    block.completed[target.index]=true;block.done=block.done+1
    return true
end
function AOMBlock.OnSave(inst)
    local b=inst._block
    if not b then return inst._aom_plan_outdated and {version=VERSION,outdated=true} or nil end
    local completed={}
    for i in pairs(b.completed) do completed[#completed+1]=i end
    table.sort(completed)
    if b.dynamic then
        local tiles,slots={},{}
        for i,t in ipairs(b.tiles) do tiles[i]={x=t.x,z=t.z} end
        for i,p in ipairs(b.slots) do slots[i]={x=p.x,z=p.z,cx=p.cx,cz=p.cz,crop=p.crop or false,index=i} end
        return {version=4,dynamic=true,season=b.season,tiles=tiles,slots=slots,completed=completed,total=b.total,upper=b.upper,optimal=b.optimal}
    end
    return {version=VERSION,combo_id=b.combo_id,season=b.season,x=b.x,z=b.z,rotation=b.rotation,
        confirmed=b.confirmed==true,completed=completed,automatic=b.automatic,positions=b.positions}
end
function AOMBlock.OnLoad(inst,data)
    -- 旧版只有总株数，无法推断真实位置；不把旧计数迁移进新地图。
    if not data then return end
    if data.version==4 and data.dynamic then
        local ok,total=require('aom_dynamic_farm').Validate(data)
        if not ok or type(data.completed)~='table' then return end
        local b={dynamic=true,version=4,season=data.season,tiles=data.tiles,slots=data.slots,total=total,upper=total,optimal=false,completed={},done=0,automatic=true,confirmed=true}
        for _,i in ipairs(data.completed) do
            if type(i)~='number' or i%1~=0 or not b.slots[i] or not b.slots[i].crop or b.completed[i] then return end
            b.completed[i]=true;b.done=b.done+1
        end
        for i,p in ipairs(b.slots) do p.index=i end
        inst._block=b
        for _,t in ipairs(b.tiles) do require('aom_farm_registry').Record(TheWorld,t.x,t.z) end
        return
    end
    if data.outdated or data.version==2 then inst._aom_plan_outdated=true;return end
    if data.version~=VERSION or not BY_ID[data.combo_id] then return end
    if not ValidNumber(data.x) or not ValidNumber(data.z) or type(data.rotation)~="number" or data.rotation%1~=0 or data.rotation<0 or data.rotation>3 then return end
    local combo=BY_ID[data.combo_id]
    if not AOMBlock.ValidateCombo(combo,data.season) then return end
    local b=NewBlock(combo,data.season,data.x,data.z,data.rotation)
    if data.automatic==true then
        b.automatic=true
        if data.positions~=nil then
            if type(data.positions)~="table" then return end
            local slots=AOMBlock.WorldSlots(b)
            b.positions={}
            for i,p in ipairs(slots) do
                local v=data.positions[i]
                if type(v)~="table" or not ValidNumber(v.x) or not ValidNumber(v.z)
                    or (v.x-p.x)^2+(v.z-p.z)^2>.16 then return end
                b.positions[i]={x=v.x,z=v.z}
            end
        end
    end
    b.confirmed=data.confirmed==true
    for _,i in ipairs(data.completed or {}) do
        if type(i)~="number" or i%1~=0 or not combo.slots[i] or not combo.slots[i].crop or b.completed[i] then return end
        b.completed[i]=true;b.done=b.done+1
    end
    inst._block=b
end
function AOMBlock.DescribeProgress(inst)
    local b=inst._block
    if not b then return L("配比：待规划") end
    if b.dynamic then return L('动态巨大化 %d/%d',b.done,b.total) end
    local combo=BY_ID[b.combo_id]
    local text=string.format("%s %d/%d",AOMBlock.BuildName(combo.ratio),b.done,combo.total)
    if #combo.not_giant>0 then
        local names={}
        for _,crop in ipairs(combo.not_giant) do names[#names+1]=AOMBlock.GetCropName(crop) end
        text=text..L("（%s不保证巨大化）",table.concat(names,Locale.Separator()))
    end
    return text
end
-- 规划是只读操作：选择位置/方向并展示，不铺地、不消耗资源。
function AOMBlock.Preview(inst,rotate)
    local store=inst.components.aom_attachment_store
    local counts=store:CountSeedsByCrop(require("aom_seed_strategy").GetCropOfSeedItem)
    local season=TheWorld.state.season
    local source=inst._rider or inst
    local x,_,z=source.Transform:GetWorldPosition()
    x,_,z=TheWorld.Map:GetTileCenterPoint(x,0,z)
    local previous=inst._block
    local candidates=BLOCKS[season] or {}
    local start=0
    if rotate and previous and previous.confirmed==false then
        x,z=previous.x,previous.z;start=(previous.rotation+1)%4
        candidates={BY_ID[previous.combo_id]}
    end
    local reason="MISSING_SEEDS"
    local invalid_reason,field_reason
    for _,combo in ipairs(candidates) do
        if HasSeeds(counts,combo.ratio) then
            local valid,why=AOMBlock.ValidateCombo(combo,season)
            if valid then
                for offset=0,3 do
                    local candidate=NewBlock(combo,season,x,z,(start+offset)%4)
                    local clear,why=CheckField(candidate,true)
                    if clear then
                        inst._block=candidate;inst._aom_plan_outdated=nil
                        return true
                    end
                    field_reason=field_reason or why
                end
            else invalid_reason=invalid_reason or why end
        end
    end
    -- 可用模板的场地失败优先于无效模板；材料足够时不误报缺种。
    return false,field_reason or invalid_reason or reason
end
function AOMBlock.Confirm(inst)
    local b=inst._block
    if not b or b.confirmed~=false then return false,"PLAN_PENDING" end
    if b.season~=TheWorld.state.season then return false,"SEASON_CHANGED" end
    local valid,why=AOMBlock.ValidateCombo(BY_ID[b.combo_id],b.season)
    if not valid then return false,why end
    local counts=inst.components.aom_attachment_store:CountSeedsByCrop(require("aom_seed_strategy").GetCropOfSeedItem)
    if not HasSeeds(counts,BY_ID[b.combo_id].ratio) then return false,"MISSING_SEEDS" end
    local clear,reason=CheckField(b,true)
    if not clear then return false,reason end
    b.confirmed=true
    return true
end
function AOMBlock.NextTile(inst)
    local b=inst._block
    if not b then return end
    local slots=AOMBlock.WorldSlots(b)
    if b.dynamic then for _,p in ipairs(slots) do if p.crop and not b.completed[p.index] then return p.cx,p.cz end end;return end
    if inst._attachment_type=="plow" then
        local ordered,seen={},{}
        for _,p in ipairs(slots) do
            local key=Key(p.cx,p.cz)
            if not seen[key] then seen[key]={x=p.cx,z=p.cz,targets={}};ordered[#ordered+1]=seen[key] end
            if p.crop and not b.completed[p.index] then seen[key].targets[#seen[key].targets+1]=p end
        end
        for _,tile in ipairs(ordered) do
            local targets=tile.targets
            if b.automatic then targets=nil end -- 自动模式开垦统一九坑，留空位不应被铲掉。
            if #tile.targets>0 and not Farm.IsFieldReady(tile.x,0,tile.z,targets) then return tile.x,tile.z end
        end
    end
    for _,p in ipairs(slots) do if p.crop and not b.completed[p.index] then return p.cx,p.cz end end
end
function AOMBlock.Sync(inst)
    if not inst._plan_net then return end
    local b=inst._block
    if not b then inst._plan_net:set("");return end
    if b.dynamic then
        local nx,nz=AOMBlock.NextTile(inst)
        -- HUD needs progress and the next tile; complete layouts stay server-side.
        local points={}
        for _,p in ipairs(b.slots) do if p.crop and not b.completed[p.index] and p.cx==nx and p.cz==nz then
            points[#points+1]=table.concat({string.format('%.4f',p.x),string.format('%.4f',p.z),p.crop},',')
        end end
        inst._plan_net:set(table.concat({'D4',b.total,b.done,b.season,nx or '',nz or '',table.concat(points,'|')},';'))
        return
    end
    local completed={}
    for i in pairs(b.completed) do completed[#completed+1]=i end
    table.sort(completed)
    local nx,nz=AOMBlock.NextTile(inst)
    inst._plan_net:set(table.concat({b.combo_id,b.x,b.z,b.rotation,b.confirmed==true and "1" or "0",table.concat(completed,","),nx or "",nz or ""},";"))
end
-- 严格解析数据，客户端从同版本模板还原预览，不接受可执行字符串。
function AOMBlock.Decode(text)
    if type(text)~="string" then return end
    if string.sub(text,1,3)=='D4;' then
        if #text>2048 then return end
        local total,done,season,x,z,raw=string.match(text,'^D4;(%d+);(%d+);([a-z]+);([^;]*);([^;]*);([^;]*)$')
        total,done=tonumber(total),tonumber(done)
        if not total or total<1 or total>576 or done>total or not BLOCKS[season] then return end
        local b={dynamic=true,total=total,done=done,season=season,confirmed=true,completed={},tiles={},slots={}}
        if x=='' and z=='' and raw=='' and done==total then return b end
        x,z=tonumber(x),tonumber(z)
        if not ValidNumber(x) or not ValidNumber(z) then return end
        b.next_x,b.next_z=x,z;b.tiles[1]={x=x,z=z}
        for part in string.gmatch(raw,'[^|]+') do
            local px,pz,crop=string.match(part,'^([^,]+),([^,]+),([a-z]+)$')
            px,pz=tonumber(px),tonumber(pz)
            local def=crop and require('prefabs/farm_plant_defs').PLANT_DEFS[crop]
            if not ValidNumber(px) or not ValidNumber(pz) or not def or not def.good_seasons[season] or math.abs(px-x)>=2 or math.abs(pz-z)>=2 or #b.slots>=9 then return end
            b.slots[#b.slots+1]={x=px,z=pz,cx=x,cz=z,crop=crop,index=#b.slots+1}
        end
        if #b.slots==0 and done<total then return end
        return b
    end
    local id,x,z,r,confirmed,done,nx,nz=string.match(text,"^([^;]+);([^;]+);([^;]+);([0-3]);([01]);([%d,]*);([^;]*);([^;]*)$")
    if not id or not BY_ID[id] then return end
    x,z=tonumber(x),tonumber(z)
    if not ValidNumber(x) or not ValidNumber(z) then return end
    local b=NewBlock(BY_ID[id],string.match(id,"^([^-]+)"),x,z,tonumber(r))
    b.confirmed=confirmed=="1"
    if nx~="" or nz~="" then
        nx,nz=tonumber(nx),tonumber(nz)
        if not ValidNumber(nx) or not ValidNumber(nz) then return end
        local _,tiles=AOMBlock.WorldSlots(b)
        if not tiles[Key(nx,nz)] then return end
        b.next_x,b.next_z=nx,nz
    end
    for n in string.gmatch(done,"%d+") do
        local i=tonumber(n)
        if not BY_ID[id].slots[i] or not BY_ID[id].slots[i].crop or b.completed[i] then return end
        b.completed[i]=true;b.done=b.done+1
    end
    return b
end
function AOMBlock.DescribePreview(b)
    if not b then return L("配比：待规划") end
    if b.dynamic then
        local text=L('动态巨大化 %d/%d',b.done,b.total)
        if b.next_x then text=text..'\n'..L('下一地块中心：%.1f，%.1f',b.next_x,b.next_z) end
        return text
    end
    local combo=BY_ID[b.combo_id]
    local width,height=combo.width,combo.height
    if b.rotation%2==1 then width,height=height,width end
    local text=L("%s；范围 %d×%d 格；方向 %d°",AOMBlock.BuildName(combo.ratio),width,height,b.rotation*90)
    local nextslot
    for _,p in ipairs(AOMBlock.WorldSlots(b)) do
        if p.crop and not b.completed[p.index] then nextslot=p;break end
    end
    if nextslot then text=text.."\n"..L("下一地块中心：%.1f，%.1f",b.next_x or nextslot.cx,b.next_z or nextslot.cz) end
    return text.."\n"..L(b.confirmed==false and "绿色坑位为预览；确认后按 F 开始" or "计划已锁定；按标记完成开垦和播种")
end

return AOMBlock
