from pathlib import Path
from zipfile import ZipFile
import hashlib
import json
import os
import shutil
import sys
import tempfile

ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT / 'tools'))
import package_mod

base = Path(__file__).resolve().parent
paths = json.loads((base / 'paths.json').read_text())
target = Path(paths['target'])
backup = Path(paths['backup'])
check = json.loads((ROOT / 'outputs/selfcheck-validation.json').read_text())
assert check['mode'] == 'release' and check['success']
assert not check['failures'] and not check['warnings']
manifest = package_mod.verify_archive(package_mod.MOD, package_mod.ARCHIVE)

def verify(folder):
    expected = set(manifest['files']) | {'INSTALL-MANIFEST.json'}
    actual = {p.relative_to(folder).as_posix() for p in folder.rglob('*') if p.is_file()}
    assert actual == expected, (actual - expected, expected - actual)
    assert json.loads((folder / 'INSTALL-MANIFEST.json').read_text()) == manifest
    for name, entry in manifest['files'].items():
        raw = (folder / name).read_bytes()
        assert len(raw) == entry['bytes'] and hashlib.sha256(raw).hexdigest() == entry['sha256'], name
        assert raw == (package_mod.MOD / name).read_bytes(), name

with tempfile.TemporaryDirectory(prefix='.tractor-install-', dir=target.parent) as temp:
    stage = Path(temp)
    with ZipFile(package_mod.ARCHIVE) as z:
        z.extractall(stage)
    verify(stage / 'Tractor')
    previous = stage / 'previous'
    os.rename(target, previous)
    try:
        os.rename(stage / 'Tractor', target)
        verify(target)
    except BaseException:
        if target.exists():
            shutil.rmtree(target)
        os.rename(previous, target)
        raise
    shutil.move(str(previous), str(backup / 'installed-before-replace'))

report = {
    'version': '0.5.21', 'source_files': len(manifest['files']),
    'archive': str(package_mod.ARCHIVE),
    'archive_sha256': hashlib.sha256(package_mod.ARCHIVE.read_bytes()).hexdigest(),
    'installed_path': str(target), 'all_source_archive_installed_bytes_match': True,
    'backup': str(backup), 'selfcheck': check,
    'game_restarted': False, 'github_pushed': False,
}
destination = ROOT / 'docs/evidence/0.5.21-game-install-validation.json'
destination.write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
shutil.copy2(ROOT / 'outputs/install-validation.json', base / 'archive-validation.json')
shutil.copy2(ROOT / 'outputs/selfcheck-validation.json', base / 'release-validation.json')
print(json.dumps({k: v for k, v in report.items() if k != 'selfcheck'}, ensure_ascii=False, indent=2))
