from pathlib import Path
import subprocess,time,threading,queue,sys
root=Path.cwd()/'outputs/findentities-probe'; conf=root/'storage/Probe/Boundary/Master';conf.mkdir(parents=True,exist_ok=True)
(conf.parent/'cluster.ini').write_text('[GAMEPLAY]\ngame_mode = survival\nmax_players = 1\npause_when_empty = false\n\n[NETWORK]\ncluster_name = LocalBoundaryProbe\noffline_cluster = true\nlan_only_cluster = true\n\n[SHARD]\nshard_enabled = false\n')
(conf/'server.ini').write_text('[NETWORK]\nserver_port = 11997\nbind_ip = 127.0.0.1\n\n[SHARD]\nis_master = true\n')
(conf/'modoverrides.lua').write_text('return {}\n')
(conf/'worldgenoverride.lua').write_text('return {override_enabled=true,preset="SURVIVAL_TOGETHER",overrides={world_size="small"}}\n')
app=Path.home()/"Library/Application Support/Steam/steamapps/common/Don't Starve Together/dontstarve_steam.app/Contents"
args=[str(app/'MacOS/dontstarve_dedicated_server_nullrenderer'),'-console','-offline','-disabledatacollection','-persistent_storage_root',str(root/'storage'),'-conf_dir','Probe','-cluster','Boundary','-shard','Master','-bind_ip','127.0.0.1','-port','11997','-ugc_directory',str(root/'ugc')]
(root/'command.txt').write_text(repr(args))
p=subprocess.Popen(args,cwd=app/'MacOS',stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,bufsize=1)
(root/'pid.txt').write_text(str(p.pid));q=queue.Queue()
def read():
 for line in p.stdout:q.put(line)
threading.Thread(target=read,daemon=True).start()
start=time.monotonic();sent=False
try:
 with (root/'engine.log').open('w') as out:
  while time.monotonic()-start<180:
   try:line=q.get(timeout=.5)
   except queue.Empty:
    if p.poll() is not None:break
    continue
   out.write(line);out.flush()
   if any(t in line for t in ('[PROBE','error','Error','Starting Up','World','world','Network','Sim paused','Success','ERROR','initialized','Version:','LUA ERROR')):print(line.rstrip(),flush=True)
   if not sent and ('Sim paused' in line or 'Registering master server' in line or 'CURL ERROR' in line and time.monotonic()-start>30):
    code=(root/'probe.lua').read_text();p.stdin.write(code.replace('\n',' ')+'\n');p.stdin.flush();sent=True;print('PROBE SENT',flush=True)
   if '[PROBE_DONE]' in line:break
finally:
 if p.poll() is None:
  p.stdin.write('c_shutdown(false)\n');p.stdin.flush()
  try:p.wait(timeout=8)
  except subprocess.TimeoutExpired:p.terminate();p.wait(timeout=5)
 print('EXIT',p.returncode,'probe_sent',sent,flush=True)
