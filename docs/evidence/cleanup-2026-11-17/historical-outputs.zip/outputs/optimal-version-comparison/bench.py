import sys,json,time,hashlib,subprocess,zipfile,io,shutil,statistics
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT/'tools'))
import seed_strategy_audit as audit
OUT=ROOT/'outputs/optimal-version-comparison'
versions={}
p=OUT/'v13'
if not p.exists():
 raw=subprocess.check_output(['git','archive','--format=zip','HEAD','mod/Tractor/scripts'])
 with zipfile.ZipFile(io.BytesIO(raw)) as z:z.extractall(p)
versions['0.5.13']=p/'mod/Tractor/scripts'
p=OUT/'v17'
if not p.exists():shutil.copytree(ROOT/'outputs/upgrade-0.5.18/install-backup/installed-before/scripts',p)
versions['0.5.17']=p
p=OUT/'v18'
if not p.exists():
 shutil.copytree(ROOT/'mod/Tractor/scripts',p)
 for f in (ROOT/'outputs/template-v2-baseline').glob('*.lua'):shutil.copyfile(f,p/f.name)
versions['0.5.18']=p
versions['current']=ROOT/'mod/Tractor/scripts'
allcases={c['id']:c for c in audit.all_balanced_cases()}
cases=[allcases['autumn/plus-5/all-six']]
cases.append(dict(id='user-45',season='autumn',tiles=[(0,0),(1,0),(1,1),(2,0),(2,1)],stock={'potato':16,'tomato':16,'eggplant':4,'garlic':8,'onion':8,'pepper':8}))
for n in (3,7):cases.append(dict(id=f'spring-square-{n}-40',season='spring',tiles=[(x,z)for z in range(n)for x in range(n)],stock={k:40 for k,r in audit.RULES.items() if 'spring'in r['seasons']}))
def run(case,path):
 w=audit.world(path);L=w.lua;g=L.globals();g.inst=w.make(case['stock'],case['season']);L.execute("inst.components.container.numslots=15")
 for x,z in case['tiles']:
  for s in range(9):g.SpawnPrefab('farm_soil').Transform.SetPosition(None,x*4+(s%3-1)*4/3,0,z*4+(s//3-1)*4/3)
 g.startx=case['tiles'][0][0]*4;g.startz=case['tiles'][0][1]*4
 g.current_dynamic=(ROOT/'mod/Tractor/scripts/aom_dynamic_farm.lua').read_text()
 L.execute("local d=assert(loadstring(current_dynamic))();tiles,slots,stock=d.Gather(inst,startx,startz);crops=require('aom_seed_layout').Crops(stock,DEFS,TheWorld.state.season)")
 start=time.monotonic()
 def guard():
  if time.monotonic()-start>15:raise TimeoutError('benchmark wall budget')
 g.benchguard=guard
 try:
  board,report=L.execute("return require('aom_seed_packing').Balanced(crops,stock,tiles,slots,DEFS,benchguard)")
  points=[dict(x=p.x,z=p.z,cx=p.cx,cz=p.cz,crop=board[i] or False)for i,p in g.slots.items()] if board else []
  errors,_=audit.independent_check(case,points)
  return dict(count=report.total,proven=bool(report.optimal),quantity=report.quantity_seconds,arrangement=report.arrangement_seconds,wall=time.monotonic()-start,errors=errors)
 except TimeoutError:
  return dict(count=None,proven=False,timeout=True,wall=time.monotonic()-start)
report={'budget_seconds':15,'note':'同机交错冷启动，两轮；直接调用各版Mod Packing.Balanced，共用原版定义和扫描输入；不会改写Mod或模版策略。','versions':{v:{'path':str(p),'sha256':{f.name:hashlib.sha256(f.read_bytes()).hexdigest()for f in p.glob('aom_seed_*.lua')}}for v,p in versions.items()},'cases':cases,'rows':[]}
for repeat in range(2):
 for ci,case in enumerate(cases):
  order=list(versions)
  if (repeat+ci)%2:order.reverse()
  for name in order:
   r={'repeat':repeat,'case':case['id'],'version':name,**run(case,versions[name])};report['rows'].append(r)
   (OUT/'benchmark.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print(json.dumps(r,ensure_ascii=False),flush=True)
