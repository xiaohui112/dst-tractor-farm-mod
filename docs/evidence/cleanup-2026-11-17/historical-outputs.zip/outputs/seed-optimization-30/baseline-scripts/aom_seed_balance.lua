-- 巨大化配比只依赖原版作物定义；从不读取地皮现有肥力。
local M={}
function M.Vector(def)
 if not def or not def.nutrient_consumption or not def.nutrient_restoration then return nil end
 local consume,restore=def.nutrient_consumption,def.nutrient_restoration
 local total,types=0,0
 for i=1,3 do total=total+(consume[i] or 0);if restore[i] then types=types+1 end end
 if types==0 then return nil end
 local per=total/types
 -- 不可整除时原版随机回补余数，不能当作确定互补配比。
 if per%1~=0 then return nil end
 local out={};for i=1,3 do out[i]=(restore[i] and per or 0)-(consume[i] or 0) end
 return out
end
function M.Tile(cells,defs)
 local net={0,0,0}
 for _,k in ipairs(cells) do if k then
  local v=M.Vector(defs[k]);if not v then return false end
  for j=1,3 do net[j]=net[j]+v[j] end
 end end
 return math.abs(net[1])+math.abs(net[2])+math.abs(net[3])<.000001,net
end
-- 通用4+4九宫格图案保留中心坑；与作物名称无关。
function M.Shape(cells)
 local counts,total,types={},0,0
 for _,k in ipairs(cells) do if k then total=total+1;if not counts[k] then counts[k]=0;types=types+1 end;counts[k]=counts[k]+1 end end
 if total==8 and types==2 then
  for _,n in pairs(counts) do if n~=4 then return true end end
  return not cells[5]
 end
 return true
end
function M.Board(board,defs)
 for t=1,#board/9 do
  local cells={};for s=1,9 do cells[s]=board[(t-1)*9+s] end
  if not M.Tile(cells,defs) or not M.Shape(cells) then return false end
 end
 return true
end
-- 枚举一格至多九株的全部互补数量组合。允许同族跨地皮，最终按真实距离验证。
function M.Patterns(crops,counts,defs,yieldfn)
 local vectors={};for i,k in ipairs(crops) do vectors[i]=M.Vector(defs[k]) end
 local patterns,current,nodes={}, {},0
 local function Search(i,left,total,x,y,z)
  nodes=nodes+1;if nodes%256==0 and yieldfn then yieldfn() end
  if i>#crops then
   if total>0 and math.abs(x)+math.abs(y)+math.abs(z)<.000001 then
    local p={n=total,counts={}};local fours=0;for j=1,#crops do p.counts[j]=current[j];if current[j]==4 then fours=fours+1 end end;p.center_gap=total==8 and fours==2;patterns[#patterns+1]=p
   end
   return
  end
  local v=vectors[i];local maximum=v and math.min(counts[crops[i]],left) or 0
  for n=0,maximum do
   current[i]=n
   Search(i+1,left-n,total+n,x+n*(v and v[1] or 0),y+n*(v and v[2] or 0),z+n*(v and v[3] or 0))
  end
 end
 Search(1,9,0,0,0,0)
 table.sort(patterns,function(a,b)
  if a.n~=b.n then return a.n>b.n end
  for i=1,#crops do if a.counts[i]~=b.counts[i] then return a.counts[i]>b.counts[i] end end
  return false
 end)
 return patterns,vectors
end
-- 连续线性松弛的安全数量上界：逐格互补还必须满足整片净变化为零。
-- 任意对偶系数均给出上界，不把未完成的搜索伪报为全局最优。
function M.Upper(crops,stock,vectors,capacity)
 local best=capacity
 local function Bound(a,b)
  local n=0
  for i,k in ipairs(crops) do local v=vectors[i]
   if v then n=n+stock[k]*math.max(0,1-a*v[1]-b*v[2]) end
  end
  best=math.min(best,math.floor(n+.000001))
 end
 Bound(0,0)
 for i,v in ipairs(vectors) do
  if v[1]~=0 then Bound(1/v[1],0) end
  if v[2]~=0 then Bound(0,1/v[2]) end
  for j=i+1,#vectors do local w=vectors[j];local det=v[1]*w[2]-v[2]*w[1]
   if math.abs(det)>.000001 then Bound((w[2]-v[2])/det,(v[1]-w[1])/det) end
  end
 end
 return best
end
-- 全局库存分配先解净变化方程；最后两个独立作物由方程直接求解，
-- 避免在大量单格组合中重复搜索不同的作物集合。
function M.Allocations(crops,stock,vectors,capacity,yieldfn,options)
 local defs=require('prefabs/farm_plant_defs').PLANT_DEFS
 local order={};for i=1,#crops do order[i]=i end
 local first,second,weight=nil,nil,-1
 for i,v in ipairs(vectors) do for j=i+1,#vectors do local w=vectors[j]
  if v[1]*w[2]-v[2]*w[1]~=0 then
   local cost=stock[crops[i]]*stock[crops[j]]
   if cost>weight then first,second,weight=i,j,cost end
  end
 end end
 if first then
  order={};for i=1,#crops do if i~=first and i~=second then order[#order+1]=i end end
  table.sort(order,function(a,b)return stock[crops[a]]<stock[crops[b]] end)
  order[#order+1]=first;order[#order+1]=second
 end
 local counts,bytotal,best,nodes,limited={}, {},0,0,false
 local seen,classes,keys={}, {},{}
 for i,k in ipairs(crops) do
  local signature=table.concat(vectors[i],',')..':'..(defs[k].family_min_count or 4)..':'..(defs[k].family_check_dist or 4)
  if not classes[signature] then classes[signature]={};keys[#keys+1]=signature end
  classes[signature][#classes[signature]+1]=i
 end
 table.sort(keys)
 local function Store(total)
  if total<=0 or total>capacity then return end
  local signature={}
  for _,key in ipairs(keys) do
   local values={};for _,i in ipairs(classes[key]) do values[#values+1]=counts[i] or 0 end;table.sort(values)
   signature[#signature+1]=key..'='..table.concat(values,',')
  end
  signature=total..';'..table.concat(signature,'|')
  if seen[signature] then return end;seen[signature]=true
  bytotal[total]=bytotal[total] or {}
  if #bytotal[total]<(options and options.uncapped and math.huge or 48) then local a={};for i=1,#crops do a[i]=counts[i] or 0 end;bytotal[total][#bytotal[total]+1]=a end
  best=math.max(best,total)
 end
 local function Allowed(i,n)
  return n>=0 and n%1==0 and n<=stock[crops[i]] and (n==0 or n>=(defs[crops[i]].family_min_count or 4))
 end
 local function Search(at,total,x,y)
  nodes=nodes+1;if nodes>(options and options.node_limit or 24000) then limited=true;return end
  if nodes%128==0 and yieldfn then yieldfn() end
  if total>capacity then return end
  if at>#order then if x==0 and y==0 then Store(total) end;return end
  if first and at==#order-1 then
   local i,j=order[at],order[at+1];local v,w=vectors[i],vectors[j];local det=v[1]*w[2]-v[2]*w[1]
   local a=(-x*w[2]+y*w[1])/det;local b=(-y*v[1]+x*v[2])/det
   if Allowed(i,a) and Allowed(j,b) then counts[i],counts[j]=a,b;Store(total+a+b) end
   counts[i],counts[j]=0,0;return
  end
  local i=order[at];local v=vectors[i];local maximum=math.min(stock[crops[i]],capacity-total)
  for n=maximum,0,-1 do if Allowed(i,n) then
   counts[i]=n;Search(at+1,total+n,x+n*v[1],y+n*v[2])
   if limited then break end
  end end
  counts[i]=0
 end
 Search(1,0,0,0)
 for _,list in pairs(bytotal) do table.sort(list,function(a,b)
  local x,y=0,0;for i=1,#crops do x=x+a[i]*a[i];y=y+b[i]*b[i] end
  if x~=y then return x<y end
  for i=1,#crops do if a[i]~=b[i] then return a[i]>b[i] end end
  return false
 end) end
 return bytotal,best,limited,nodes
end
return M
