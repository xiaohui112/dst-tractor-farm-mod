-- 完整的坑位约束搜索。启发式只提供下界；较大数量逐个排除后才交付计划。
-- 域同时满足逐格互补、库存、原版距离同族、坑距及4+4中心留空。
local M={}
function M.Prepare(crops,stock,defs,vectors,capacity,yieldfn)
 local first,second,weight=nil,nil,-1
 for i,v in ipairs(vectors) do for j=i+1,#vectors do local w=vectors[j]
  if v[1]*w[2]-v[2]*w[1]~=0 and stock[crops[i]]*stock[crops[j]]>weight then first,second,weight=i,j,stock[crops[i]]*stock[crops[j]] end
 end end
 local product=1
 for c,k in ipairs(crops) do if c~=first and c~=second then product=product*(stock[k]-(defs[k].family_min_count or 4)+2);if product>1200000 then break end end end
 local budget=product<=1200000 and math.max(24000,product*2+16) or 24000
 local allocations,upper,limited,nodes=require('aom_seed_balance').Allocations(crops,stock,vectors,capacity,yieldfn,{uncapped=true,node_limit=budget})
 return {allocations=allocations,upper=upper,limited=limited,nodes=nodes}
end
function M.Maximize(crops,stock,tiles,slots,defs,seed,lower,upper,yieldfn,options)
 local Balance=require('aom_seed_balance')
 local Layout=require('aom_seed_layout')
 local patterns=Balance.Patterns(crops,stock,defs,yieldfn)
 local geometry=Layout.Geometry(tiles,slots,defs,yieldfn);geometry.balanced=true
 local K,N,T=#crops,#slots,#tiles
 local powers,single,all={}, {},0
 for c=0,K do powers[c]=2^c;single[2^c]=c;all=all+2^c end
 local function Has(mask,c)return mask%(powers[c]*2)>=powers[c] end
 local sizes,values={},{}
 local function Values(mask)
  if not values[mask] then
   local a={};for c=0,K do if Has(mask,c) then a[#a+1]=c end end
   values[mask]=a;sizes[mask]=#a
  end
  return values[mask]
 end
 local neighbors,conflicts={},{}
 local spacing=(GetFarmTillSpacing and GetFarmTillSpacing() or 1.25)^2
 for i,p in ipairs(slots) do
  conflicts[i]={}
  for j,q in ipairs(slots) do if j~=i and (p.x-q.x)^2+(p.z-q.z)^2<=spacing then conflicts[i][#conflicts[i]+1]=j end end
 end
 for c,k in ipairs(crops) do
  neighbors[c]={}
  for i=1,N do local a={};for _,q in ipairs(geometry.near[i]) do if q.d<=(defs[k].family_check_dist or 4)^2 then a[#a+1]=q.j end end;neighbors[c][i]=a end
 end
 local caps={};for c,k in ipairs(crops) do caps[c]=stock[k] end
 local reachCache,commonCache,mapCache={}, {},{}
 local function NeighborMap(c,i)
  mapCache[c]=mapCache[c] or {}
  if not mapCache[c][i] then local a={};for _,j in ipairs(neighbors[c][i]) do a[j]=true end;mapCache[c][i]=a end
  return mapCache[c][i]
 end
 local function Reach(c,i)
  reachCache[c]=reachCache[c] or {}
  if not reachCache[c][i] then
   local a={};for _,j in ipairs(neighbors[c][i]) do for _,q in ipairs(neighbors[c][j]) do a[q]=true end end
   reachCache[c][i]=a
  end
  return reachCache[c][i]
 end
 local function Common(c,i,j)
  commonCache[c]=commonCache[c] or {};commonCache[c][i]=commonCache[c][i] or {}
  if not commonCache[c][i][j] then
   local a={};local map=NeighborMap(c,j)
   for _,q in ipairs(neighbors[c][i]) do if map[q] then a[#a+1]=q end end
   commonCache[c][i][j]=a
  end
  return commonCache[c][i][j]
 end
 local minimum={};for c,k in ipairs(crops) do minimum[c]=defs[k].family_min_count or 4 end
 local nodes,propagations,work=0,0,0
 local aborted=false
 local function Step()
  work=work+1;if options and options.work_limit and work>options.work_limit then aborted=true end;if work%128==0 and yieldfn then yieldfn() end
 end
 local function Copy(a)local b={};for i,v in ipairs(a) do b[i]=v end;return b end
 -- 带容量二分匹配与交替图强连通分量，排除多个同族争用同一批坑位的死路。
 local function Cardinality(domains,target)
  local required={[0]=N-target};local sum=N-target
  for c=1,K do required[c]=caps[c];sum=sum+caps[c] end
  local owners,match={},{};for c=0,K do owners[c]={} end
  local order={};for i=1,N do order[i]=i;Values(domains[i]) end
  table.sort(order,function(a,b)return sizes[domains[a]]~=sizes[domains[b]] and sizes[domains[a]]<sizes[domains[b]] or sizes[domains[a]]==sizes[domains[b]] and a<b end)
  local function Assign(i,seen)
   for _,c in ipairs(Values(domains[i])) do if not seen[c] then
    seen[c]=true
    if #owners[c]<required[c] then owners[c][#owners[c]+1]=i;match[i]=c;return true end
    for at,j in ipairs(owners[c]) do if Assign(j,seen) then owners[c][at]=i;match[i]=c;return true end end
   end end
   return false
  end
  for _,i in ipairs(order) do if not Assign(i,{}) then return false,false end end
  local extra=sum~=N and 1 or 0
  local adj={};for i=1,N+K+1+extra do adj[i]={} end
  for i,mask in ipairs(domains) do for _,c in ipairs(Values(mask)) do
   if match[i]~=c then adj[i][#adj[i]+1]=N+c+1 end
  end end
  for c=0,K do for _,i in ipairs(owners[c]) do adj[N+c+1][#adj[N+c+1]+1]=i end end
  if extra==1 then
   local residual=N+K+2
   for c=0,K do if #owners[c]<required[c] then adj[N+c+1][#adj[N+c+1]+1]=residual end end
   for i=1,N do adj[residual][#adj[residual]+1]=i end
  end
  local index,low,onstack,stack,component={}, {}, {}, {},{}
  local serial,components=0,0
  local function Visit(i)
   serial=serial+1;index[i],low[i]=serial,serial;stack[#stack+1]=i;onstack[i]=true
   for _,j in ipairs(adj[i]) do
    if not index[j] then Visit(j);low[i]=math.min(low[i],low[j])
    elseif onstack[j] then low[i]=math.min(low[i],index[j]) end
   end
   if low[i]==index[i] then
    components=components+1
    repeat local j=table.remove(stack);onstack[j]=nil;component[j]=components until j==i
   end
  end
  for i=1,N+K+1+extra do if not index[i] then Visit(i) end end
  local changed=false
  for i,mask in ipairs(domains) do
   for _,c in ipairs(Values(mask)) do if match[i]~=c and component[i]~=component[N+c+1] then domains[i]=domains[i]-powers[c];changed=true end end
   if domains[i]==0 then return false,false end
  end
  return true,changed
 end
 local profileGroups,groupKeys={},{}
 for c,k in ipairs(crops) do
  local key=table.concat(Balance.Vector(defs[k]),',')..':'..minimum[c]..':'..(defs[k].family_check_dist or 4)
  if not groupKeys[key] then groupKeys[key]=#profileGroups+1;profileGroups[#profileGroups+1]={} end
  local group=profileGroups[groupKeys[key]];group[#group+1]=c
 end
 local activeProfiles=nil
 local profileData,matchCache,matchOrder={}, {},{}
 local matchHead,matchTail=1,0
 local function ProfileBounds(lo,hi)
  if not activeProfiles or #activeProfiles>2000 then return lo,hi end
  local outlo,outhi={},{};for c=1,K do outlo[c]=math.huge;outhi[c]=-1 end
  local ranges={}
  for g,group in ipairs(profileGroups) do local tokens={g};for _,c in ipairs(group) do tokens[#tokens+1]=lo[c];tokens[#tokens+1]=hi[c] end;ranges[g]=table.concat(tokens,',') end
  local any=false
  for _,profile in ipairs(activeProfiles) do
   local data=profileData[profile]
   if not data then
    data={};profileData[profile]=data
    for g,group in ipairs(profileGroups) do local values={};for _,c in ipairs(group) do values[#values+1]=profile[c] end;table.sort(values);data[g]={values=values,key=table.concat(values,',')} end
   end
   local results={};local feasible=true
   for g,group in ipairs(profileGroups) do
    local key=ranges[g]..'/'..data[g].key;local result=matchCache[key]
    if result==nil then
     local values=data[g].values;local taken,assignment={},{}
     local lower,upper={},{};for _,c in ipairs(group) do lower[c]=math.huge;upper[c]=-1 end
     local found=false
     local function Match(at)
      if at>#group then found=true;for _,c in ipairs(group) do lower[c]=math.min(lower[c],assignment[c]);upper[c]=math.max(upper[c],assignment[c]) end;return end
      local c=group[at];local seen={}
      for i,n in ipairs(values) do if not taken[i] and not seen[n] and n>=lo[c] and n<=hi[c] then
       seen[n]=true;taken[i]=true;assignment[c]=n;Match(at+1);taken[i]=nil
      end end
     end
     Match(1);result=found and {lo=lower,hi=upper} or false
     matchCache[key]=result;matchTail=matchTail+1;matchOrder[matchTail]=key
     if matchTail-matchHead>20000 then matchCache[matchOrder[matchHead]]=nil;matchOrder[matchHead]=nil;matchHead=matchHead+1 end
    end
    if not result then feasible=false;break end;results[g]=result
   end
   if feasible then
    any=true
    for g,group in ipairs(profileGroups) do for _,c in ipairs(group) do outlo[c]=math.min(outlo[c],results[g].lo[c]);outhi[c]=math.max(outhi[c],results[g].hi[c]) end end
   end
  end
  if not any then return nil end
  return outlo,outhi
 end
 local function Propagate(domains,lists,target)
  local changed=true;local limits,lowerlimits={},{};for c,k in ipairs(crops) do limits[c]=caps[c];lowerlimits[c]=0 end
  while changed do
   if aborted then return false end
   changed=false;propagations=propagations+1;Step()
   local function Set(i,mask)
    if mask==0 then return false end
    if mask~=domains[i] then domains[i]=mask;changed=true end
    return true
   end
   local counts,possible={},{}
   for c=0,K do counts[c]=0;possible[c]=0 end
   for i,mask in ipairs(domains) do
    if mask==0 then return false end
    local c=single[mask];if c then counts[c]=counts[c]+1 end
    for _,v in ipairs(Values(mask)) do possible[v]=possible[v]+1 end
    if c and c>0 then for _,j in ipairs(conflicts[i]) do if not Set(j,Has(domains[j],0) and 1 or 0) then return false end end end
   end
   local stocklimit={[0]=N-target}
   for c,k in ipairs(crops) do stocklimit[c]=caps[c] end
   for c=0,K do
    if counts[c]>stocklimit[c] then return false end
    if c==0 and possible[c]<stocklimit[c] then return false end
    if c>0 and counts[c]>0 and possible[c]<minimum[c] then return false end
    local exclude=counts[c]==stocklimit[c] or c>0 and possible[c]<minimum[c]
    local force=c==0 and possible[c]==stocklimit[c]
    for i,mask in ipairs(domains) do if Has(mask,c) and single[mask]==nil then
     if exclude then if not Set(i,mask-powers[c]) then return false end
     elseif force then if not Set(i,powers[c]) then return false end end
    end end
   end
   local tilemin,tilemax={},{}
   for t=1,T do
    tilemin[t]={};tilemax[t]={}
    for c=1,K do tilemin[t][c]=9;tilemax[t][c]=0 end
    for _,pattern in ipairs(lists[t]) do for c=1,K do tilemin[t][c]=math.min(tilemin[t][c],pattern.counts[c]);tilemax[t][c]=math.max(tilemax[t][c],pattern.counts[c]) end end
   end
   -- 原版同族条件是“每株至少三个邻居”，允许五株以上非团状支持。
   for c=1,K do
    for i,mask in ipairs(domains) do if Has(mask,c) then
     local support,n={},0
     for _,j in ipairs(neighbors[c][i]) do if Has(domains[j],c) then n=n+1;support[n]=j end end
     local bytile={};for t=1,T do bytile[t]=0 end
     for _,j in ipairs(support) do local t=math.floor((j-1)/9)+1;bytile[t]=bytile[t]+1 end
     local supportmax,outside=0,0;local capacity={}
     for t=1,T do capacity[t]=math.min(bytile[t],tilemax[t][c]);supportmax=supportmax+capacity[t];outside=outside+math.max(0,tilemin[t][c]-bytile[t]) end
     local sumcapacity=supportmax
     supportmax=math.min(supportmax,limits[c]-outside)
     if supportmax<minimum[c] then if not Set(i,domains[i]-powers[c]) then return false end
     elseif single[domains[i]]==c then
      if n==minimum[c] then for _,j in ipairs(support) do if not Set(j,powers[c]) then return false end end end
      -- 半径内某格的可用坑位恰好全部必需时，直接强制这些支持点。
      for _,j in ipairs(support) do local t=math.floor((j-1)/9)+1
       if bytile[t]>0 and minimum[c]-(sumcapacity-capacity[t])==bytile[t] then if not Set(j,powers[c]) then return false end end
      end
      -- 不超过2m-1株且每株至少m个同族时，每对株必有至少2m-n个公共支持。
      if limits[c]<=2*minimum[c]-1 then
       local reachable=Reach(c,i);local required=2*minimum[c]-limits[c]
       for j,other in ipairs(domains) do if Has(other,c) then
        if not reachable[j] then if not Set(j,other-powers[c]) then return false end
        else
         local common={};for _,q in ipairs(Common(c,i,j)) do if Has(domains[q],c) then common[#common+1]=q end end
         if #common<required then if not Set(j,domains[j]-powers[c]) then return false end
         elseif single[domains[j]]==c and #common==required then for _,q in ipairs(common) do if not Set(q,powers[c]) then return false end end end
        end
       end end
      end
      -- 库存恰好四颗时，四株必成团；推广到库存较多时的“半径外配额”。
      local outside=0;local inside={};for _,j in ipairs(neighbors[c][i]) do inside[j]=true end
      for j,other in ipairs(domains) do if not inside[j] and single[other]==c then outside=outside+1 end end
      local limit=limits[c]-minimum[c]
      if outside>limit then return false end
      if outside==limit then for j,other in ipairs(domains) do if not inside[j] and Has(other,c) and single[other]==nil then if not Set(j,other-powers[c]) then return false end end end end
     end
    end end
    Step()
   end
   local mins,maxs={},{};local summin,summax=0,0
   for t=1,T do
    local fixed,available={},{}
    for c=0,K do fixed[c]=0;available[c]=0 end
    for i=(t-1)*9+1,t*9 do local mask=domains[i];local c=single[mask]
     if c then fixed[c]=fixed[c]+1 end
     for _,v in ipairs(Values(mask)) do available[v]=available[v]+1 end
    end
    local allowed={};local lo,hi=9,0
    for _,p in ipairs(lists[t]) do
     local ok=9-p.n>=fixed[0] and 9-p.n<=available[0]
     if p.center_gap and not Has(domains[(t-1)*9+5],0) then ok=false end
     if ok then for c=1,K do if p.counts[c]<fixed[c] or p.counts[c]>available[c] then ok=false;break end end end
     if ok then allowed[#allowed+1]=p;lo=math.min(lo,p.n);hi=math.max(hi,p.n) end
     Step()
    end
    if #allowed==0 then return false end
    lists[t]=allowed;mins[t],maxs[t]=lo,hi;summin=summin+lo;summax=summax+hi
   end
   if target<summin or target>summax then return false end
   local globalmin,globalmax={},{};for c=1,K do globalmin[c]=0;globalmax[c]=0 end
   for t=1,T do
    local lo=target-(summax-maxs[t]);local hi=target-(summin-mins[t])
    local allowed={};local mincount,maxcount={},{};local gap=true
    for c=0,K do mincount[c]=9;maxcount[c]=0 end
    for _,p in ipairs(lists[t]) do if p.n>=lo and p.n<=hi then
     allowed[#allowed+1]=p;gap=gap and p.center_gap
     for c=0,K do local n=c==0 and 9-p.n or p.counts[c];mincount[c]=math.min(mincount[c],n);maxcount[c]=math.max(maxcount[c],n) end
    end end
    if #allowed==0 then return false end;lists[t]=allowed
    if gap and not Set((t-1)*9+5,Has(domains[(t-1)*9+5],0) and 1 or 0) then return false end
    for c=1,K do globalmin[c]=globalmin[c]+mincount[c];globalmax[c]=globalmax[c]+maxcount[c] end
    for c=0,K do
     local fixed,available=0,0
     for i=(t-1)*9+1,t*9 do if single[domains[i]]==c then fixed=fixed+1 end;if Has(domains[i],c) then available=available+1 end end
     if fixed>maxcount[c] or available<mincount[c] then return false end
     if fixed==maxcount[c] then
      for i=(t-1)*9+1,t*9 do local mask=domains[i];if Has(mask,c) and single[mask]==nil and not Set(i,mask-powers[c]) then return false end end
     elseif available==mincount[c] then
      for i=(t-1)*9+1,t*9 do if Has(domains[i],c) and not Set(i,powers[c]) then return false end end
     end
    end
   end
   local totalmax,totalmin=0,0
   for c=1,K do
    globalmax[c]=math.min(globalmax[c],limits[c])
    globalmin[c]=math.max(globalmin[c],lowerlimits[c])
    if globalmax[c]<minimum[c] then globalmax[c]=0 end
    if globalmin[c]>0 then globalmin[c]=math.max(globalmin[c],minimum[c]) end
    if globalmin[c]>globalmax[c] then return false end
    totalmax=totalmax+globalmax[c];totalmin=totalmin+globalmin[c]
   end
   if totalmax<target or totalmin>target then return false end
   if activeProfiles then
    local lo,hi=ProfileBounds(globalmin,globalmax);if not lo then return false end
    totalmin,totalmax=0,0
    for c=1,K do
     if lo[c]>lowerlimits[c] then lowerlimits[c]=lo[c];changed=true end
     globalmin[c],globalmax[c]=lo[c],hi[c]
     totalmin,totalmax=totalmin+lo[c],totalmax+hi[c]
    end
   end
   for c=1,K do
    local lo=math.max(globalmin[c],target-(totalmax-globalmax[c]))
    if lo>0 then lo=math.max(lo,minimum[c]) end
    local hi=math.min(globalmax[c],target-(totalmin-globalmin[c]))
    if hi<minimum[c] then hi=0 end
    if lo>hi then return false end
    if hi<limits[c] then limits[c]=hi;changed=true end
    local fixed,available=0,0
    for _,mask in ipairs(domains) do if single[mask]==c then fixed=fixed+1 end;if Has(mask,c) then available=available+1 end end
    if fixed>hi or available<lo then return false end
    if fixed==hi then
     for i,mask in ipairs(domains) do if single[mask]==nil and Has(mask,c) and not Set(i,mask-powers[c]) then return false end end
    elseif available==lo then
     for i,mask in ipairs(domains) do if Has(mask,c) and not Set(i,powers[c]) then return false end end
    end
   end
   if not changed then
    local feasible,narrowed=Cardinality(domains,target)
    if not feasible then return false end
    changed=narrowed
   end
  end
  return true
 end
 local signatures={}
 for c,k in ipairs(crops) do signatures[c]=table.concat(Balance.Vector(defs[k]),',')..':'..minimum[c]..':'..(defs[k].family_check_dist or 4)..':'..stock[k] end
 -- 将搜索顺序按田形规范化；只改变分支顺序，所有距离仍取现场原始坐标。
 local canonical,canonicalKey=0,nil
 local function Transform(x,z,r)
  if r>=4 then x=-x end
  for _=1,r%4 do x,z=-z,x end
  return x,z
 end
 for r=0,7 do
  local pts={};local minx,minz,maxx,maxz=math.huge,math.huge,-math.huge,-math.huge
  for _,t in ipairs(tiles) do local x,z=Transform(t.x/4,t.z/4,r);pts[#pts+1]={x,z};minx=math.min(minx,x);minz=math.min(minz,z);maxx=math.max(maxx,x);maxz=math.max(maxz,z) end
  table.sort(pts,function(a,b)return a[2]~=b[2] and a[2]<b[2] or a[2]==b[2] and a[1]<b[1] end)
  local tokens={string.format('%04d:%04d',1000-(maxx-minx),maxz-minz)}
  for _,t in ipairs(pts) do tokens[#tokens+1]=(t[1]-minx)..','..(t[2]-minz) end
  local key=table.concat(tokens,';');if not canonicalKey or key<canonicalKey then canonical,canonicalKey=r,key end
 end
 local rankCache={}
 local function Ranks(direction)
  direction=direction or 0
  if rankCache[direction] then return rankCache[direction] end
  local ordered,rank={},{};for i=1,N do ordered[i]=i end
  if direction>=4 then for i=1,N do rank[i]=direction==4 and i or N+1-i end;rankCache[direction]=rank;return rank end
  local function Position(i)
   local x,z=Transform(slots[i].x,slots[i].z,canonical)
   for _=1,direction do x,z=-z,x end
   return x,z
  end
  table.sort(ordered,function(a,b)local x,z=Position(a);local u,v=Position(b);return z~=v and z<v or z==v and x<u end)
  for at,i in ipairs(ordered) do rank[i]=at end
  rankCache[direction]=rank;return rank
 end
 local function Cover(allocation,target,nodeLimit,direction)
  for _,list in ipairs(conflicts) do if #list>0 then return nil,false,false end end
  local radius,minimumFamily=nil,nil
  for c,k in ipairs(crops) do if allocation[c]>0 then
   if allocation[c]>7 then return nil,false,false end
   if radius and radius~=(defs[k].family_check_dist or 4) then return nil,false,false end
   radius=defs[k].family_check_dist or 4
   if (defs[k].family_min_count or 4)~=4 then return nil,false,false end
   minimumFamily=c
  end end
  if not minimumFamily then return nil,false,false end
  local adjacent,linked={},{}
  for i=1,N do adjacent[i]=neighbors[minimumFamily][i];linked[i]={};for _,j in ipairs(adjacent[i]) do linked[i][j]=true end end
  local rank=Ranks(direction)
  local classof,classkeys,classes={}, {},0
  for c,k in ipairs(crops) do
   local key=table.concat(Balance.Vector(defs[k]),',')
   if not classkeys[key] then classes=classes+1;classkeys[key]=classes end
   classof[c]=classkeys[key]
  end
  local totals={};for g=1,classes do totals[g]=0 end
  for c,n in ipairs(allocation) do totals[classof[c]]=totals[classof[c]]+n end
  local projection={}
  for _,p in ipairs(patterns) do
   local counts={};for g=1,classes do counts[g]=0 end
   for c,n in ipairs(p.counts) do counts[classof[c]]=counts[classof[c]]+n end
   projection[p]=counts
  end
  local holes=N-target;local initialLists={}
  for t=1,T do
   local list={}
   for _,p in ipairs(patterns) do
    local ok=p.n>=9-holes
    for c=1,K do if p.counts[c]>allocation[c] then ok=false;break end end
    if ok then list[#list+1]=p end
   end
   if holes>=9 then local p={n=0,counts={}};for c=1,K do p.counts[c]=0 end;projection[p]={};for g=1,classes do projection[p][g]=0 end;list[#list+1]=p end
   if #list==0 then return nil,false,true end;initialLists[t]=list
  end
  local cut=false;local visits=0
  local function CheckBudget()
   visits=visits+1;Step()
   if aborted then return false end
   if nodeLimit and visits>nodeLimit*32 then cut=true;return false end
   return true
  end
  local function Refine(lists,free,board,c,counts)
   local out={};local totalmin,totalmax=0,0
   for t,list in ipairs(lists) do
    local capacity=0;for i=(t-1)*9+1,t*9 do if free[i] or board[i] then capacity=capacity+1 end end
    local allowed={};local lo,hi=9,0
    for _,p in ipairs(list) do
     if p.n<=capacity and (not c or p.counts[c]==counts[t]) and not (p.center_gap and board[(t-1)*9+5]) then
      allowed[#allowed+1]=p;lo=math.min(lo,p.n);hi=math.max(hi,p.n)
     end
    end
    if #allowed==0 then return nil end
    out[t]=allowed;totalmin=totalmin+lo;totalmax=totalmax+hi
   end
   if target<totalmin or target>totalmax then return nil end
   local changed=true
   while changed do
    changed=false
    local mins,maxs,summin,summax={}, {}, {},{}
    for g=1,classes do summin[g]=0;summax[g]=0 end
    for t,list in ipairs(out) do
     mins[t],maxs[t]={},{}
     for g=1,classes do mins[t][g]=N;maxs[t][g]=0 end
     for _,p in ipairs(list) do for g,n in ipairs(projection[p]) do mins[t][g]=math.min(mins[t][g],n);maxs[t][g]=math.max(maxs[t][g],n) end end
     for g=1,classes do summin[g]=summin[g]+mins[t][g];summax[g]=summax[g]+maxs[t][g] end
    end
    for g=1,classes do if totals[g]<summin[g] or totals[g]>summax[g] then return nil end end
    for t,list in ipairs(out) do
     local kept={}
     for _,p in ipairs(list) do
      local ok=true
      for g,n in ipairs(projection[p]) do if n<totals[g]-(summax[g]-maxs[t][g]) or n>totals[g]-(summin[g]-mins[t][g]) then ok=false;break end end
      if ok then kept[#kept+1]=p else changed=true end
     end
     if #kept==0 then return nil end;out[t]=kept
     Step()
    end
   end
   return out
  end
  local function Search(free,board,lists,remaining,left,blank)
   nodes=nodes+1
   if not CheckBudget() then return nil end
   if left==0 then if Layout.Valid(board,geometry) then return board end;return nil end
   lists=Refine(lists,free,board);if not lists then return nil end
   local coarseTile,coarseGroups,coarseSize=nil,nil,math.huge
   for t,list in ipairs(lists) do
    local groups,keys={},{}
    for _,p in ipairs(list) do
     local key=table.concat(projection[p],',')
     if not groups[key] then groups[key]={};keys[#keys+1]=key end
     groups[key][#groups[key]+1]=p
    end
    if #keys>1 and #keys<=8 and #keys<coarseSize then
     coarseTile,coarseGroups,coarseSize=t,{},#keys
     for _,key in ipairs(keys) do coarseGroups[#coarseGroups+1]=groups[key] end
    end
   end
   if coarseTile then
    local function Score(group)
     local score=0
     for _,n in ipairs(projection[group[1]]) do if n>0 and n<4 then score=score+(4-n)^2 end end
     return score
    end
    table.sort(coarseGroups,function(a,b)return Score(a)<Score(b) end)
    for _,group in ipairs(coarseGroups) do
     local nextlists=Copy(lists);nextlists[coarseTile]=group
     local result=Search(free,board,nextlists,remaining,left,blank)
     if result then return result end
     if cut or aborted then return nil end
    end
    return nil
   end
   local component,regions,degrees={}, {},{}
   for i,v in ipairs(free) do if v and not component[i] then
    local id=#regions+1;local region={points={i},tiles={}};regions[id]=region;component[i]=id
    local at=1
    while at<=#region.points do
     local point=region.points[at];at=at+1
     local t=math.floor((point-1)/9)+1;region.tiles[t]=(region.tiles[t] or 0)+1
     local degree=0
     for _,j in ipairs(adjacent[point]) do if free[j] then
      degree=degree+1
      if not component[j] then component[j]=id;region.points[#region.points+1]=j end
     end end
     degrees[point]=degree
    end
   end end
   if #regions>1 then
    local sums={[0]=true};local total=0
    for _,n in ipairs(remaining) do if n>0 then for q=total,0,-1 do if sums[q] then sums[q+n]=true end end;total=total+n end end
    local empty=0
    for _,region in ipairs(regions) do
     local filled=math.min(#region.points,total);while filled>0 and not sums[filled] do filled=filled-1 end
     empty=empty+#region.points-filled
    end
    if empty>blank then return nil end
   end
   local regionAllowed={}
   for c,n in ipairs(remaining) do if n>0 then
    regionAllowed[c]={};local possible=false
    for id,region in ipairs(regions) do if #region.points>=n then
     local capacity=0;local ok=true
     for t,list in ipairs(lists) do
      local lo,hi=9,0;for _,p in ipairs(list) do lo=math.min(lo,p.counts[c]);hi=math.max(hi,p.counts[c]) end
      local available=region.tiles[t] or 0
      if available<lo then ok=false;break end
      capacity=capacity+math.min(available,hi)
     end
     if ok and capacity>=n then regionAllowed[c][id]=true;possible=true end
    end end
    if not possible then return nil end
   end end
   local first,degree=nil,math.huge
   for i,v in ipairs(free) do if v then
    local n=degrees[i];if n<degree or n==degree and rank[i]<rank[first] then first,degree=i,n end
   end end
   if not first then return nil end
   local function Hole()
    if blank==0 then return nil end
    local nextfree=Copy(free);nextfree[first]=false
    local nextlists=Refine(lists,nextfree,board)
    if nextlists then return Search(nextfree,Copy(board),nextlists,remaining,left,blank-1) end
   end
   if degree<4 then return Hole() end
   local triedHole=false
   if seed and not seed[first] and blank>0 then
    triedHole=true;local candidate=Hole();if candidate then return candidate end
    if cut or aborted then return nil end
   end
   local kinds={};for c,n in ipairs(remaining) do if n>0 then kinds[#kinds+1]=c end end
   table.sort(kinds,function(a,b)
    local x,y=seed and seed[first]==crops[a] and 1 or 0,seed and seed[first]==crops[b] and 1 or 0
    if x~=y then return x>y end
    return remaining[a]~=remaining[b] and remaining[a]<remaining[b] or remaining[a]==remaining[b] and a<b
   end)
   local equivalent={}
   for _,c in ipairs(kinds) do
    if cut or aborted then return nil end
    local signature=table.concat(Balance.Vector(defs[crops[c]]),',')..':'..remaining[c]
    local quota={};local fixed=true
    for t,list in ipairs(lists) do
     local n=list[1].counts[c];quota[t]=n
     for _,p in ipairs(list) do if p.counts[c]~=n then fixed=false;break end end
    end
    -- 固定的逐格配额完全相同的未放置作物，可互换几何颜色；不合并同族数量。
    if fixed then signature='fixed:'..remaining[c]..':'..table.concat(quota,',') end
    if not equivalent[signature] and regionAllowed[c][component[first]] then
     equivalent[signature]=true
     local size=remaining[c];local lo,hi={},{}
     local required,capacity=0,0
     for t,list in ipairs(lists) do
      lo[t],hi[t]=9,0
      for _,p in ipairs(list) do lo[t]=math.min(lo[t],p.counts[c]);hi[t]=math.max(hi[t],p.counts[c]) end
      required=required+lo[t];capacity=capacity+hi[t]
     end
     if required<=size and capacity>=size and hi[math.floor((first-1)/9)+1]>0 then
      -- n<=7、每点度数至少3：任意两点必有公共邻居，因此完整候选都在锚点两跳内。
      local reachable={};for _,j in ipairs(adjacent[first]) do if free[j] then for _,q in ipairs(adjacent[j]) do if free[q] then reachable[q]=true end end end end
      local candidates={}
      for i in pairs(reachable) do if i~=first and hi[math.floor((i-1)/9)+1]>0 then candidates[#candidates+1]=i end end
      table.sort(candidates,function(a,b)
       local sa,sb=seed and seed[a]==crops[c] and 1 or 0,seed and seed[b]==crops[c] and 1 or 0
       if sa~=sb then return sa>sb end
       local pa,pb=slots[a],slots[b];local p=slots[first]
       local function Cost(q)
        local x,z=q.x-p.x,q.z-p.z;local axis=(direction or 0)%5
        local cross=axis==1 and x or axis==2 and z or axis==3 and x+z or axis==4 and x-z or 0
        return x*x+z*z+cross*cross*.8
       end
       local x,y=Cost(pa),Cost(pb)
       return x~=y and x<y or x==y and rank[a]<rank[b]
      end)
      local candidateIndex={};for at,i in ipairs(candidates) do candidateIndex[i]=at end
      local selected,selectedSet,support,residual,low={}, {}, {}, {},{}
      local count={};for t=1,T do count[t]=0 end
      for i,n in pairs(degrees) do residual[i]=n;if n<4 then low[i]=true end end
      local suffix={}
      local points=Copy(candidates);points[#points+1]=first
      for _,i in ipairs(points) do
       local a={};local n=0
       for at=#candidates,1,-1 do if linked[i][candidates[at]] then n=n+1 end;a[at]=n end
       suffix[i]=a
      end
      local function Push(i)
       local n=1
       for _,j in ipairs(selected) do if linked[i][j] then support[j]=support[j]+1;n=n+1 end end
       selected[#selected+1]=i;selectedSet[i]=true;support[i]=n
       local t=math.floor((i-1)/9)+1;count[t]=count[t]+1
       for _,j in ipairs(adjacent[i]) do if residual[j] then
        residual[j]=residual[j]-1
        if not selectedSet[j] and residual[j]<4 then low[j]=true else low[j]=nil end
       end end
      end
      local function Pop()
       local i=table.remove(selected);selectedSet[i]=nil;support[i]=nil
       for _,j in ipairs(selected) do if linked[i][j] then support[j]=support[j]-1 end end
       local t=math.floor((i-1)/9)+1;count[t]=count[t]-1
       for _,j in ipairs(adjacent[i]) do if residual[j] then
        residual[j]=residual[j]+1
        if not selectedSet[j] and residual[j]<4 then low[j]=true else low[j]=nil end
       end end
      end
      Push(first)
      local function Generate(at)
       if not CheckBudget() then return nil end
       local need=size-#selected
       if #candidates-at+1<need then return nil end
       local deficit=0;for t=1,T do if count[t]>hi[t] then return nil end;deficit=deficit+math.max(0,lo[t]-count[t]) end
       if deficit>need then return nil end
       -- 移走本组后，剩余种植点也必须各有至少三个同族候选邻居。
       -- 被孤立的点只能一并归入本组或成为空坑，提前剪掉无法覆盖的碎片。
       local forced,unavailable=0,0
       for i in pairs(low) do
        forced=forced+1
        if not candidateIndex[i] or candidateIndex[i]<at then unavailable=unavailable+1 end
       end
       if forced>need+blank or unavailable>blank then return nil end
       for _,i in ipairs(selected) do
        local n=support[i]
        if n+need<4 then return nil end
        if n+math.min(need,suffix[i][at] or 0)<4 then return nil end
       end
       if need==0 then
        local nextfree,nextboard=Copy(free),Copy(board)
        for _,i in ipairs(selected) do nextfree[i]=false;nextboard[i]=crops[c] end
        local nextlists=Refine(lists,nextfree,nextboard,c,count)
        if nextlists then
         local nextremaining=Copy(remaining);nextremaining[c]=0
         return Search(nextfree,nextboard,nextlists,nextremaining,left-1,blank)
        end
        return nil
       end
       for atindex=at,#candidates-need+1 do
        local i=candidates[atindex]
        Push(i)
        local result=Generate(atindex+1)
        Pop()
        if result then return result end
        if cut or aborted then return nil end
       end
       return nil
      end
      local result=Generate(1);if result then return result,false,true end
     end
    end
   end
   if cut or aborted or triedHole then return nil end
   return Hole()
  end
  local free,board={},{};for i=1,N do free[i]=true;board[i]=false end
  local left=0;for _,n in ipairs(allocation) do if n>0 then left=left+1 end end
  local result=Search(free,board,initialLists,Copy(allocation),left,holes)
  return result,cut,true
 end
 local preparedData
 local function Find(target,allocation,nodeLimit,direction,patternFirst)
  for c,k in ipairs(crops) do caps[c]=allocation and allocation[c] or stock[k] end
  activeProfiles=not allocation and preparedData and not preparedData.limited and preparedData.allocations[target] or nil
  if allocation then
   local board,cut,eligible=Cover(allocation,target,nodeLimit,direction)
   if eligible then return board,cut end
  end
  local rank=Ranks(direction)
  local initial,lists={},{}
  for i=1,N do initial[i]=target==N and all-1 or all end
  for t=1,T do
   local a={};for _,p in ipairs(patterns) do a[#a+1]=p end
   local zero={n=0,counts={}};for c=1,K do zero.counts[c]=0 end;a[#a+1]=zero;lists[t]=a
  end
  local visited,cut=0,false
  local function Search(domains,patternsbytile)
   nodes=nodes+1;visited=visited+1;Step()
   if nodeLimit and visited>nodeLimit then cut=true;return nil end
   if aborted or options and options.node_limit and nodes>options.node_limit then aborted=true;return nil end
   if not Propagate(domains,patternsbytile,target) then return nil end
   -- 配额已经固定时，少量同族作为完整组决定；大族仍允许多个分离支持团。
   -- 这避免在“大库存+少量余种”时把同一个小族拆成大量逐坑决定。
   local sumcaps=0;for _,n in ipairs(caps) do sumcaps=sumcaps+n end
   if sumcaps==target then
    local chosenCrop,choiceRank=nil,math.huge
    local assigned,possible={},{}
    for c=1,K do assigned[c]={};possible[c]={} end
    for i,mask in ipairs(domains) do
     for _,c in ipairs(Values(mask)) do if c>0 then possible[c][#possible[c]+1]=i end end
     local c=single[mask];if c and c>0 then assigned[c][#assigned[c]+1]=i end
    end
    for c,n in ipairs(caps) do
     if n>=4 and n<=7 and minimum[c]==4 and #assigned[c]<n then
      local score=(#possible[c]-#assigned[c])*10+(n-#assigned[c])
      if score<choiceRank then chosenCrop,choiceRank=c,score end
     end
    end
    if chosenCrop then
     local c=chosenCrop;local size=caps[c];local near,linked={},{}
     for i=1,N do linked[i]={};for _,j in ipairs(neighbors[c][i]) do linked[i][j]=true end end
     local anchors={}
     if #assigned[c]>0 then anchors[1]=assigned[c][1]
     else for _,i in ipairs(possible[c]) do anchors[#anchors+1]=i end;table.sort(anchors,function(a,b)return rank[a]<rank[b] end) end
     local fixedQuota,lo,hi={}, {},{}
     for t,list in ipairs(patternsbytile) do
      fixedQuota[t]={};lo[t],hi[t]=9,0
      for _,p in ipairs(list) do fixedQuota[t][p.counts[c]]=true;lo[t]=math.min(lo[t],p.counts[c]);hi[t]=math.max(hi[t],p.counts[c]) end
     end
     local generated=0
     for _,anchor in ipairs(anchors) do
      if aborted or cut then return nil end
      local reachable={}
      for _,j in ipairs(neighbors[c][anchor]) do if Has(domains[j],c) then
       for _,q in ipairs(neighbors[c][j]) do if Has(domains[q],c) then reachable[q]=true end end
      end end
      local selected,selectedSet,counts={}, {},{};for t=1,T do counts[t]=0 end
      local ok=true
      if #assigned[c]>0 then
       for _,i in ipairs(assigned[c]) do
        if not reachable[i] then ok=false;break end
        selected[#selected+1]=i;selectedSet[i]=true;local t=math.floor((i-1)/9)+1;counts[t]=counts[t]+1
       end
      else selected[1]=anchor;selectedSet[anchor]=true;counts[math.floor((anchor-1)/9)+1]=1 end
      if ok then
       local candidates={}
       for i in pairs(reachable) do if not selectedSet[i] and (#assigned[c]>0 or rank[i]>rank[anchor]) then candidates[#candidates+1]=i end end
       table.sort(candidates,function(a,b)
        local pa,pb,p=slots[a],slots[b],slots[anchor]
        local x,y=(pa.x-p.x)^2+(pa.z-p.z)^2,(pb.x-p.x)^2+(pb.z-p.z)^2
        return x~=y and x<y or x==y and rank[a]<rank[b]
       end)
       local suffix,tileSuffix={},{}
       local points=Copy(candidates);for _,i in ipairs(selected) do points[#points+1]=i end
       for _,i in ipairs(points) do
        local row={};local n=0;for at=#candidates,1,-1 do if linked[i][candidates[at]] then n=n+1 end;row[at]=n end;suffix[i]=row
       end
       for t=1,T do local row={};local n=0;for at=#candidates,1,-1 do if math.floor((candidates[at]-1)/9)+1==t then n=n+1 end;row[at]=n end;tileSuffix[t]=row end
       local function Generate(at)
        generated=generated+1;Step()
        if aborted then return nil end
        if nodeLimit and generated>nodeLimit*64 then cut=true;return nil end
        local need=size-#selected
        if #candidates-at+1<need then return nil end
        local deficit=0
        for t=1,T do
         if counts[t]>hi[t] or counts[t]+math.min(need,tileSuffix[t][at] or 0)<lo[t] then return nil end
         deficit=deficit+math.max(0,lo[t]-counts[t])
        end
        if deficit>need then return nil end
        for _,i in ipairs(selected) do
         local n=0;for _,j in ipairs(selected) do if linked[i][j] then n=n+1 end end
         if n+math.min(need,suffix[i][at] or 0)<4 then return nil end
        end
        if need==0 then
         for t=1,T do if not fixedQuota[t][counts[t]] then return nil end end
         local child=Copy(domains)
         for i,mask in ipairs(child) do
          if selectedSet[i] then child[i]=powers[c]
          elseif Has(mask,c) then child[i]=mask-powers[c];if child[i]==0 then return nil end end
         end
         return Search(child,Copy(patternsbytile))
        end
        for atindex=at,#candidates-need+1 do
         local i=candidates[atindex];local t=math.floor((i-1)/9)+1
         selected[#selected+1]=i;selectedSet[i]=true;counts[t]=counts[t]+1
         local result=Generate(atindex+1)
         counts[t]=counts[t]-1;selectedSet[i]=nil;selected[#selected]=nil
         if result then return result end
         if aborted or cut then return nil end
        end
        return nil
       end
       local result=Generate(1);if result then return result end
      end
     end
     return nil
    end
   end
   -- 少量逐格配比先分支；半径内同族上界会立即排除整片不可行配比，
   -- 无需把每个坑的颜色逐一试完才发现某端地皮只能容纳一两株同族。
   local patternTile,patternRank=nil,math.huge
   for t,list in ipairs(patternsbytile) do
    if #list>1 and #list<=6 then
     local degree=0;for _,edge in ipairs(geometry.edges) do if edge.a==t or edge.b==t then degree=degree+1 end end
     local rank=#list*100-degree
     if rank<patternRank or rank==patternRank and Ranks(direction)[(t-1)*9+1]<Ranks(direction)[(patternTile-1)*9+1] then patternTile,patternRank=t,rank end
    end
   end
   if patternTile and (allocation or patternFirst) then
    for _,pattern in ipairs(patternsbytile[patternTile]) do
     if aborted or cut then return nil end
     local child=Copy(patternsbytile);child[patternTile]={pattern}
     local candidate=Search(Copy(domains),child);if candidate then return candidate end
    end
    return nil
   end
   local chosen,bestRank=nil,math.huge
   for i,mask in ipairs(domains) do if single[mask]==nil then
    Values(mask)
    local score=sizes[mask]*10000+#patternsbytile[math.floor((i-1)/9)+1]*10+#geometry.near[i]
    if score<bestRank or score==bestRank and rank[i]<rank[chosen] then chosen,bestRank=i,score end
   end end
   if not chosen then
    local board={};for i,mask in ipairs(domains) do local c=single[mask];board[i]=c>0 and crops[c] or false end
    if Layout.Valid(board,geometry) then return board end
    return nil
   end
   local options=Copy(Values(domains[chosen]));local used={}
   for c=1,K do used[c]=0 end
   for _,mask in ipairs(domains) do local c=single[mask];if c and c>0 then used[c]=used[c]+1 end end
   local function Cost(c)
    if c==0 then return -1000 end
    local n=0;for _,j in ipairs(neighbors[c][chosen]) do if single[domains[j]]==c then n=n+1 end end
    return n*100+(seed and seed[chosen]==crops[c] and 30 or 0)+(caps[c]-used[c])
   end
   table.sort(options,function(a,b)local x,y=Cost(a),Cost(b);return x~=y and x>y or x==y and a<b end)
   local tried={}
   for _,c in ipairs(options) do
    if aborted or cut then return nil end
    local equivalent=false
    if c>0 and used[c]==0 then for _,previous in ipairs(tried) do if previous>0 and used[previous]==0 and signatures[c]==signatures[previous] and caps[c]==caps[previous] then
     equivalent=true;for _,mask in ipairs(domains) do if Has(mask,c)~=Has(mask,previous) then equivalent=false;break end end
     if equivalent then break end
    end end end
    if not equivalent then
     tried[#tried+1]=c
     local child=Copy(domains);child[chosen]=powers[c]
     local candidate=Search(child,Copy(patternsbytile));if candidate then return candidate end
    end
   end
   return nil
  end
  local board=Search(initial,lists)
  return board,cut
 end
 local initialupper=upper
 if lower==upper then return seed,{total=lower,upper=lower,relaxed_upper=upper,optimal=true,nodes=0,propagations=0,mode='upper-bound-witness'} end
 local vectors={};for c,k in ipairs(crops) do vectors[c]=Balance.Vector(defs[k]) end
 preparedData=options and options.prepared or M.Prepare(crops,stock,defs,vectors,upper,yieldfn)
 local allocations,globalupper,limited=preparedData.allocations,preparedData.upper,preparedData.limited
 if not limited then upper=math.min(upper,globalupper) end
 for target=upper,lower+1,-1 do
  if limited or allocations[target] then
  local board,directCut=nil,true
  for _,budget in ipairs({32,256}) do
   for direction=0,5 do
    for strategy=0,1 do
     board,directCut=Find(target,nil,budget,direction,strategy==1)
     if board or aborted or not directCut then break end
    end
    if board or aborted or not directCut then break end
   end
   if board or aborted or not directCut then break end
  end
  if aborted then return seed,{total=lower,upper=initialupper,optimal=false,pending=true,nodes=nodes,propagations=propagations,prepared=preparedData} end
  local pending={};for _,allocation in ipairs(allocations[target] or {}) do pending[#pending+1]=allocation end
  table.sort(pending,function(a,b)
   local x,y=0,0;for c=1,K do if a[c]>0 then x=x+1 end;if b[c]>0 then y=y+1 end end
   return x<y
  end)
  -- 先分配小份预算给不同配额，避免在首个不可行配额上穷尽后才尝试可行配额。
  -- 截断分支始终保留；最后一轮无截断，只有完整排除后才降低目标数量。
  if not board and directCut then
  for round,budget in ipairs({32,256,2048,16384,math.huge}) do
   local again={}
   for _,allocation in ipairs(pending) do
    local cut;board,cut=Find(target,allocation,budget,round-1)
    if board or aborted then break end
    if cut then again[#again+1]=allocation end
   end
   if board or aborted then break end
   pending=again;if #pending==0 then break end
  end
  if aborted then return seed,{total=lower,upper=initialupper,optimal=false,pending=true,nodes=nodes,propagations=propagations,prepared=preparedData} end
  if not board and limited then board=Find(target) end
  end
  if aborted then return seed,{total=lower,upper=initialupper,optimal=false,pending=true,nodes=nodes,propagations=propagations,prepared=preparedData} end
  if board then return board,{total=target,upper=target,relaxed_upper=initialupper,optimal=true,nodes=nodes,propagations=propagations,mode='exact-pit-constraints'} end
  end
 end
 return seed,{total=lower,upper=lower,relaxed_upper=initialupper,optimal=true,nodes=nodes,propagations=propagations,mode='exact-pit-constraints'}
end
return M
