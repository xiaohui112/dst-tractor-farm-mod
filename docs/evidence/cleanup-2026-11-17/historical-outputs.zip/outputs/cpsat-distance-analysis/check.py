import sys,time,json,struct,math
from pathlib import Path
sys.path.insert(0,'tools/cpsat_benchmark');import benchmark as b
snap=Path('outputs/cpsat-comparison/source-snapshot').resolve();b.freeze(snap)
case=next(c for c in b.scenarios() if c['id']=='autumn/square-3/all-40/GIANT')
w,slots=b.context(case);L=w.lua;g=L.globals()
calc=L.eval('function() local a=8+4/3;local b=4+4/3;return string.format("%.17g",a),string.format("%.17g",b),string.format("%.17g",a-b),string.format("%.17g",(a-b)^2), (a-b)^2<=16 end')()
print('LUA numeric chain',calc,flush=True)
f32=lambda x:struct.unpack('f',struct.pack('f',x))[0]
a,c=8+4/3,4+4/3
print('hypothetical float32 transform',f32(a),f32(c),f32(a)-f32(c),(f32(a)-f32(c))**2, 'float32 arithmetic d2',f32(f32(f32(a)-f32(c))**2),flush=True)
# Diagnostic only: normalize solely radius-boundary errors <= 1e-10 in derived geometry.
L.execute('''
local original=Layout.Geometry
patched_pairs=0
Layout.Geometry=function(tiles,slots,defs,...)
 local g=original(tiles,slots,defs,...)
 local radii={};for _,d in pairs(defs)do if d.family_check_dist then radii[d.family_check_dist^2]=true end end
 for i,p in ipairs(slots)do
  local present={};for _,q in ipairs(g.near[i])do present[q.j]=q end
  for j,q in ipairs(slots)do
   local d=(p.x-q.x)^2+(p.z-q.z)^2
   for radius in pairs(radii)do if d>radius and d-radius<=1e-10 then
    if present[j]then present[j].d=radius else g.near[i][#g.near[i]+1]={j=j,d=radius}end
    patched_pairs=patched_pairs+1;break
   end end
  end
 end
 return g
end
''')
stages=[];start=time.perf_counter();cpu=time.process_time()
def stage(s):stages.append({'stage':s,'wall':time.perf_counter()-start,'cpu':time.process_time()-cpu})
def guard():
 if time.perf_counter()-start>10:raise TimeoutError()
g.stage=stage;g.guard=guard
L.execute('trace={Stage=function(_,s)stage(s)end,Skip=function()end,Context=function()end,Emit=function()end,Clock=os.clock};result,proof=Packing.Balanced(crops,stock,tiles,slots,DEFS,guard,trace,task)')
result={'numeric_chain':calc,'patched_geometry_only':True,'quantity':g.proof.total,'optimal':g.proof.optimal,'mode':g.proof.mode,'quantity_cpu':g.proof.quantity_seconds,'arrangement_cpu':g.proof.arrangement_seconds,'wall':time.perf_counter()-start,'stages':stages,'patched_pair_occurrences':g.patched_pairs,'board':[g.result[i] for i in range(1,82)]}
print(json.dumps(result,indent=2),flush=True)
Path('outputs/cpsat-distance-analysis/result.json').write_text(json.dumps(result,indent=2))
