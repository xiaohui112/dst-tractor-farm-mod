import sys,json,time,hashlib
from pathlib import Path
ROOT=Path.cwd();sys.path.insert(0,str(ROOT/'tools/cpsat_benchmark'))
import benchmark as b
snapshot=ROOT/'outputs/cpsat-comparison/source-snapshot'
b.freeze(snapshot)
case=next(c for c in b.scenarios() if c['id']=='autumn/square-3/all-40/GIANT')
w,slots=b.context(case);L=w.lua;g=L.globals()
base=b.manifest(snapshot)
current=b.manifest()
diff=[p for p,h in base.items() if current.get(p)!=h]
print('source differences',diff,flush=True)
g.cpu_limit=20;g.wall_limit=45
start=time.perf_counter();cpu=time.process_time();stages=[];ctx={};progress=[];last=0
method_times={};method_name=None;method_start=0
class Stop(Exception):pass
def stage(s):
 stages.append({'stage':s,'wall':time.perf_counter()-start,'cpu':time.process_time()-cpu,'context':dict(ctx)})
 print('STAGE',stages[-1],flush=True)
def context(t):
 global last,method_name,method_start
 values=dict(t.items())
 now=time.process_time()-cpu
 if 'active_method' in values:
  if method_name:method_times[method_name]=method_times.get(method_name,0)+now-method_start
  method_name=values['active_method'];method_start=now
 ctx.update(values)
 elapsed=time.process_time()-cpu
 if elapsed-last>=1:
  progress.append({'wall':time.perf_counter()-start,'cpu':elapsed,**ctx});last=elapsed
  print('PROGRESS',progress[-1],flush=True)
def guard():
 if time.process_time()-cpu>g.cpu_limit or time.perf_counter()-start>g.wall_limit:raise Stop()
g.stage_hook=stage;g.context_hook=context;g.guard=guard
L.execute('''
trace={Stage=function(_,s)stage_hook(s)end,Skip=function()end,Context=function(_,v)context_hook(v)end,Emit=function()end,Clock=os.clock}
calls={}
local function Wrap(module,name)
 local m=require(module);local old=m[name]
 m[name]=function(...)
  local r={name=module..'.'..name,start=os.clock()};calls[#calls+1]=r
  if name=='Maximize' then
   local args={...};r.target=args[8];r.lower=args[7];r.tile_count=#args[3]
   if args[10] then
    local oldobserve=args[10].observe
    args[10].observe=function(p)r.progress=p;if oldobserve then oldobserve(p)end end
   end
  end
  local a,b,c=old(...);r.finish=os.clock()
  if type(b)=='table' then r.total=b.total;r.upper=b.upper;r.nodes=b.nodes;r.optimal=b.optimal end
  return a,b,c
 end
end
Wrap('aom_seed_initial','Build');Wrap('aom_seed_regions','Find')
Wrap('aom_seed_exact','Prepare');Wrap('aom_seed_exact','Maximize')
Wrap('aom_seed_feasible','Find');Wrap('aom_seed_balance','TargetAllocations')
''')
# Measure after harness setup, matching the benchmark entry point.
start=time.perf_counter();cpu=time.process_time()
status='finished'
try:L.execute('result,proof=Packing.Balanced(crops,stock,tiles,slots,DEFS,guard,trace,task)')
except Stop:status='budget'
if method_name:method_times[method_name]=method_times.get(method_name,0)+time.process_time()-cpu-method_start
calls=[]
for v in g.calls.values():
 item=dict(v.items())
 if 'progress' in item:item['progress']={k:x for k,x in item['progress'].items() if isinstance(x,(str,int,float,bool))}
 calls.append(item)
report={'case':case,'snapshot':str(snapshot),'snapshot_unchanged':b.manifest(snapshot)==base,'current_source_differences':diff,'status':status,'wall':time.perf_counter()-start,'cpu':time.process_time()-cpu,'stages':stages,'progress':progress,'context':ctx,'calls':calls,'method_cpu':method_times}
if g.proof is not None:report['proof']={k:g.proof[k] for k in ('total','upper','optimal','mode','quantity_seconds','arrangement_seconds')}
(ROOT/'outputs/cpsat-autumn-analysis/profile-detailed.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
print(json.dumps(report,ensure_ascii=False,indent=2),flush=True)
