import json,sys,collections
from pathlib import Path
sys.path.insert(0,'tools/cpsat_benchmark');import benchmark as b
b.freeze(Path('outputs/cpsat-comparison/source-snapshot').resolve())
r=json.load(open('outputs/cpsat-comparison/benchmark.json'));cid='autumn/square-3/all-40/GIANT'
case=next(c for c in r['cases'] if c['id']==cid);w,slots=b.context(case);L=w.lua;g=L.globals();geo=b.geometry(w)
row=next(x for x in r['rows'] if x['case_id']==cid and x['solver']=='cp-sat-8');board=row['board']
print('CROPS',list(g.crops.values())); print('CP used',dict(collections.Counter(board)));print('CP first',row['solutions'][:10])
for t in range(9):
 a=board[t*9:t*9+9];print('TILE',slots[t*9]['cx'],slots[t*9]['cz'],dict(collections.Counter(a)),[a[i:i+3] for i in (0,3,6)])
stripes=['carrot']*3+['corn']*3+['potato']*3
for label,values in [('stripes',stripes*9),('cp',board)]:
 fails=[];border=[]
 for i,k in enumerate(values):
  ns=[j for j,p in enumerate(slots) if values[j]==k and (slots[i]['x']-p['x'])**2+(slots[i]['z']-p['z'])**2<=16]
  if len(ns)<4:
   close=[(j, (slots[i]['x']-p['x'])**2+(slots[i]['z']-p['z'])**2) for j,p in enumerate(slots) if values[j]==k and abs((slots[i]['x']-p['x'])**2+(slots[i]['z']-p['z'])**2-16)<1e-8]
   fails.append({'i':i,'p':slots[i],'crop':k,'family':len(ns),'boundary':close})
 print(label,'valid',b.validate(case,w,slots,values)[0],'fails',fails)
L.execute('warm,warmreport=require("aom_seed_initial").Build(crops,stock,tiles,slots,DEFS,nil,{rounds=32,repairs=32})')
warm=[g.warm[i] for i in range(1,82)];print('WARM',g.warmreport.total,dict(collections.Counter(warm)))
for t in range(9):
 a=warm[t*9:t*9+9];print('WARM_TILE',slots[t*9]['cx'],slots[t*9]['cz'],dict(collections.Counter(a)),[a[i:i+3] for i in (0,3,6)])
Path('outputs/cpsat-autumn-analysis/witness.json').write_text(json.dumps({'case':case,'slots':slots,'cp_board':board,'warm_board':warm,'cp_solutions':row['solutions']},ensure_ascii=False,indent=2))
