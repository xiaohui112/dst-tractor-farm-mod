import json,sys,time,collections
from pathlib import Path
sys.path.insert(0,'tools/cpsat_benchmark');import benchmark as b
from ortools.sat.python import cp_model
b.freeze(Path('outputs/cpsat-comparison/source-snapshot').resolve())
r=json.load(open('outputs/cpsat-autumn-analysis/witness.json'));case=r['case'];warm=r['warm_board'];slots=r['slots']
results=[]
for mode,free in [('hole-tile',[8]),('bottom-right-2x2',[4,6,7,8]),('whole',list(range(9)))]:
 w,slots=b.context(case);start=time.perf_counter();model,x,crops=b.model_for(w,slots)
 for i,k in enumerate(warm):
  if i//9 not in free:
   for ci,c in enumerate(crops):model.add(x[i][ci]==int(k==c))
 model.add(sum(v for row in x for v in row)==81)
 changed=[1-x[i][crops.index(k)] if k else 1 for i,k in enumerate(warm)]
 model.minimize(sum(changed))
 solver=cp_model.CpSolver();solver.parameters.num_search_workers=1;solver.parameters.max_time_in_seconds=5
 status=solver.solve(model);elapsed=time.perf_counter()-start
 row={'mode':mode,'free_tiles':free,'status':solver.status_name(status),'wall':elapsed,'changes':round(solver.objective_value) if status in (cp_model.OPTIMAL,cp_model.FEASIBLE) else None}
 if status in (cp_model.OPTIMAL,cp_model.FEASIBLE):
  board=[next((k for ci,k in enumerate(crops) if solver.value(x[i][ci])),False) for i in range(81)]
  row['errors'],row['metrics']=b.validate(case,w,slots,board);row['board']=board
  row['changed_pits']=[{'i':i,'tile':i//9,'from':warm[i],'to':v} for i,v in enumerate(board) if warm[i]!=v]
 results.append(row);print({k:v for k,v in row.items() if k not in ('board',)},flush=True)
w,slots=b.context(case);L=w.lua;g=L.globals();start=time.process_time()
L.execute('patterns,vectors=Balance.Patterns(crops,stock,DEFS);prepared=require("aom_seed_exact").Prepare(crops,stock,DEFS,vectors,81);entry=prepared.Get(81)')
entry=g.entry;prep={'cpu':time.process_time()-start,'profiles':len(entry.allocations),'limited':entry.limited,'nodes':entry.nodes,'patterns':len(g.patterns)}
print('PREP',prep,flush=True)
# Canonicalize interchangeable species counts exactly as TargetAllocations does.
cpused=collections.Counter(r['cp_board']);groups={}
for k in g.crops.values():
 v=g.Balance.Vector(g.DEFS[k]);groups.setdefault(tuple(v.values()),[]).append(k)
canonical=cpused.copy()
for keys in groups.values():
 vals=sorted((cpused[k] for k in keys),reverse=True)
 for k,v in zip(keys,vals):canonical[k]=v
wanted=[canonical[k] for k in g.crops.values()];matches=[]
for i,a in entry.allocations.items():
 if [a[j] for j in range(1,len(g.crops)+1)]==wanted:matches.append(i)
prep['cp_quota']=wanted;prep['cp_quota_positions']=matches
prep['first_profiles']=[[entry.allocations[i][j] for j in range(1,len(g.crops)+1)] for i in range(1,min(5,len(entry.allocations))+1)]
Path('outputs/cpsat-autumn-analysis/neighborhoods.json').write_text(json.dumps({'experiments':results,'preparation':prep},ensure_ascii=False,indent=2))
print('PREP_DETAILS',prep,flush=True)
