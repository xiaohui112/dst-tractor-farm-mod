-- 同族优先装填：逐地皮数量回溯，以及真实距离上的受限同族团覆盖搜索。
-- 只在快速候选未达到库存上界时使用；不包含作物、配比或地形模板。
local M={}
local function Empty(n)local a={};for i=1,n do a[i]=false end;return a end
function M.Local(allocation,tiles,defs,yieldfn)
 local remaining,total={},0
 for i,a in ipairs(allocation) do remaining[i]=a.n;total=total+a.n end
 local memo,nodes={},0;local bins={}
 local function Search(left,space)
  nodes=nodes+1;if nodes>10000 then return false end
  if nodes%16==0 and yieldfn then yieldfn() end
  if left==0 then return true end
  if space==0 or left>space*9 then return false end
  local chunks,first,largest=0,nil,0
  for i,n in ipairs(remaining) do
   chunks=chunks+math.ceil(n/9)
   if n>largest then first,largest=i,n end
  end
  if chunks>space*2 then return false end
  local key=table.concat(remaining,',')..';'..space
  if memo[key] then return false end
  local minimum=defs[allocation[first].k].family_min_count or 4
  local options={}
  for a=math.min(9,remaining[first]),minimum,-1 do
   local rest=remaining[first]-a
   if rest==0 or rest>=minimum then
    options[#options+1]={first=first,a=a,total=a}
    for second,n in ipairs(remaining) do if second~=first and n>0 then
     local othermin=defs[allocation[second].k].family_min_count or 4
     for b=math.min(9-a,n),othermin,-1 do
      if n-b==0 or n-b>=othermin then options[#options+1]={first=first,a=a,second=second,b=b,total=a+b} end
     end
    end end
   end
  end
  table.sort(options,function(a,b)
   if a.total~=b.total then return a.total>b.total end
   if a.a~=b.a then return a.a>b.a end
   return (a.second or 0)<(b.second or 0)
  end)
  for _,o in ipairs(options) do
   remaining[first]=remaining[first]-o.a
   if o.second then remaining[o.second]=remaining[o.second]-o.b end
   bins[#bins+1]=o
   if Search(left-o.total,space-1) then return true end
   bins[#bins]=nil;remaining[first]=remaining[first]+o.a
   if o.second then remaining[o.second]=remaining[o.second]+o.b end
  end
  memo[key]=true;return false
 end
 -- 数量优先：先用全部可用地皮找完整解，不能让最小占地尝试先耗尽预算。
 for used=#tiles,#tiles do
  memo={};bins={}
  if Search(total,used) then
   local board=Empty(#tiles*9)
   -- 相同作物的整块/半块数量尽量连续放置，留待整片排列核对和整理。
   table.sort(bins,function(a,b)
    local x,y=math.min(a.first,a.second or a.first),math.min(b.first,b.second or b.first)
    return x~=y and x<y or x==y and a.a>b.a
   end)
   for t,o in ipairs(bins) do
    local pos=(t-1)*9
    for _=1,o.a do pos=pos+1;board[pos]=allocation[o.first].k end
    for _=1,o.b or 0 do pos=pos+1;board[pos]=allocation[o.second].k end
   end
   return board,{nodes=nodes,mode='tile-families'}
  end
  if nodes>10000 then break end
 end
 return nil,{nodes=nodes,limited=nodes>10000,mode='tile-families'}
end
-- 平均分配并不是唯一可用配比。直接在真实库存内枚举单格/双种同族数量，
-- 固定整片目标数量及种类，允许不同作物的使用量变化。
function M.Flexible(crops,counts,tiles,defs,total,kinds,yieldfn)
 local stock,used={},{};for i,k in ipairs(crops) do stock[i]=counts[k];used[i]=false end
 local nodes,memo,bins=0,{},{}
 local function Search(left,space,types)
  nodes=nodes+1;if nodes>18000 then return false end
  if nodes%16==0 and yieldfn then yieldfn() end
  if left==0 then return types==kinds end
  if space==0 or left>space*9 or types>kinds or kinds-types>space*2 then return false end
  local available,unseen,maxsingle=0,0,0;local tokens={}
  for i,n in ipairs(stock) do
   local minimum=defs[crops[i]].family_min_count or 4
   if n>=minimum then available=available+n;if not used[i] then unseen=unseen+1 end;maxsingle=math.max(maxsingle,math.min(9,n)) end
   tokens[i]=n..':'..(used[i] and '1' or '0')
  end
  if available<left or unseen<kinds-types then return false end
  local key=table.concat(tokens,',')..';'..left..';'..space
  if memo[key] then return false end
  local options={};local seen={};local maxfill=maxsingle
  local function Add(i,a,j,b)
   local added=(used[i] and 0 or 1)+(j and not used[j] and 1 or 0)
   local n=a+(b or 0)
   if types+added>kinds or left<n or left-n>(space-1)*9 then return end
   -- 同库存、同参与状态的作物在此阶段等价，避免重排种名消耗预算。
   local sig=stock[i]..':'..tostring(used[i])..':'..a..'/'..(j and stock[j]..':'..tostring(used[j])..':'..b or '')
   if seen[sig] then return end;seen[sig]=true
   local x,y=stock[i]-a,j and stock[j]-b or 0
   local waste=(x>0 and x<4 and x or 0)+(y>0 and y<4 and y or 0)
   options[#options+1]={first=i,a=a,second=j,b=b,total=n,added=added,waste=waste}
  end
  for i,n in ipairs(stock) do
   local minimum=defs[crops[i]].family_min_count or 4
   for a=math.min(n,9),minimum,-1 do Add(i,a) end
   for j=i+1,#stock do
    local othermin=defs[crops[j]].family_min_count or 4
    for a=minimum,math.min(n,9-othermin) do
     for b=othermin,math.min(stock[j],9-a) do maxfill=math.max(maxfill,a+b);Add(i,a,j,b) end
    end
   end
  end
  if left>space*maxfill then return false end
  table.sort(options,function(a,b)
   if a.total~=b.total then return a.total>b.total end
   if a.added~=b.added then return a.added>b.added end
   if a.waste~=b.waste then return a.waste<b.waste end
   if a.first~=b.first then return a.first<b.first end
   if (a.second or 0)~=(b.second or 0) then return (a.second or 0)<(b.second or 0) end
   return a.a>b.a
  end)
  for _,o in ipairs(options) do
   local firstused,secondused=used[o.first],o.second and used[o.second]
   stock[o.first]=stock[o.first]-o.a;used[o.first]=true
   if o.second then stock[o.second]=stock[o.second]-o.b;used[o.second]=true end
   bins[#bins+1]=o
   if Search(left-o.total,space-1,types+o.added) then return true end
   bins[#bins]=nil;stock[o.first]=stock[o.first]+o.a;used[o.first]=firstused
   if o.second then stock[o.second]=stock[o.second]+o.b;used[o.second]=secondused end
  end
  memo[key]=true;return false
 end
 if not Search(total,#tiles,0) then return nil,{mode='flexible-families',nodes=nodes,limited=nodes>18000} end
 local board=Empty(#tiles*9)
 for t,o in ipairs(bins) do local pos=(t-1)*9
  for _=1,o.a do pos=pos+1;board[pos]=crops[o.first] end
  for _=1,o.b or 0 do pos=pos+1;board[pos]=crops[o.second] end
 end
 return board,{mode='flexible-families',nodes=nodes}
end
function M.Families(allocation,slots,defs,yieldfn)
 local pieces,counts,total,radius={}, {},0,math.huge
 for _,a in ipairs(allocation) do
  local d=defs[a.k]
  if (d.family_min_count or 4)~=4 then return nil end
  radius=math.min(radius,d.family_check_dist or 4);total=total+a.n
  local n=math.ceil(a.n/9);local base=math.floor(a.n/n);local extra=a.n%n
  for i=1,n do local size=base+(i<=extra and 1 or 0);pieces[#pieces+1]={k=a.k,size=size};counts[size]=(counts[size] or 0)+1 end
 end
 if #pieces==0 then return nil end
 local active,near,compatible,distance={}, {}, {}, {}
 for i,p in ipairs(slots) do
  active[i]=true;near[i]={};compatible[i]={};distance[i]={}
  for j,q in ipairs(slots) do
   local d=(p.x-q.x)^2+(p.z-q.z)^2;distance[i][j]=d
   if d<=radius^2 then near[i][#near[i]+1]=j;compatible[i][j]=true end
  end
  if i%9==0 and yieldfn then yieldfn() end
 end
 local nodes,trials,memo,solution=0,0,{},{}
 local function Count(i)local n=0;for _,j in ipairs(near[i]) do if active[j] then n=n+1 end end;return n end
 local function Limited()return nodes>12000 or trials>500000 end
 local function Search(left,blanks)
  nodes=nodes+1;if Limited() then return false end
  if yieldfn then yieldfn() end
  if left==0 then return true end
  local first,degree,forced=nil,math.huge,0;local sig={}
  for i=1,#slots do
   sig[i]=active[i] and '1' or '0'
   if active[i] then
    local n=Count(i);if n<4 then forced=forced+1 end
    if n<degree then first,degree=i,n end
   end
  end
  if forced>blanks then return false end
  local sizes={};for n=4,9 do sizes[#sizes+1]=counts[n] or 0 end
  local key=table.concat(sig)..':'..blanks..':'..table.concat(sizes,',')
  if memo[key] then return false end
  if degree<4 then
   active[first]=false;local ok=Search(left,blanks-1);active[first]=true;return ok
  end
  local candidates,seen={},{}
  local function Add(group)
   trials=trials+1;if trials%64==0 and yieldfn then yieldfn() end
   if Limited() then return end
   for _,i in ipairs(group) do
    local n=0;for _,j in ipairs(group) do if compatible[i][j] then n=n+1 end end
    if n<4 then return end
   end
   local sorted={};for i,j in ipairs(group) do sorted[i]=j end;table.sort(sorted)
   local signature=table.concat(sorted,',');if seen[signature] then return end;seen[signature]=true
   local cost=0
   for x=1,#group do for y=x+1,#group do cost=cost+distance[group[x]][group[y]] end end
   candidates[#candidates+1]={group=sorted,score=cost/#group,key=signature,size=#group}
  end
  if (counts[4] or 0)>0 then
   -- 四株同族必须两两在距离内，完整枚举该锚点邻域中的四元组。
   local neighbors={};for _,j in ipairs(near[first]) do if j~=first and active[j] then neighbors[#neighbors+1]=j end end
   for a=1,#neighbors-2 do local i=neighbors[a]
    for b=a+1,#neighbors-1 do local j=neighbors[b]
     if compatible[i][j] then for c=b+1,#neighbors do local k=neighbors[c]
      if compatible[i][k] and compatible[j][k] then Add({first,i,j,k}) end
     end end
    end
   end
  end
  -- 五到九株只要求每株有足够同族，不应错误收紧为全部两两相邻。
  -- 由真实坐标生成各方向的紧凑邻域，再枚举其中的受限子集。
  local p=slots[first];local pools={}
  for size=5,9 do if (counts[size] or 0)>0 then
   for axis=0,4 do
    local indices={};for i in ipairs(slots) do if i~=first and active[i] then indices[#indices+1]=i end end
    local function Cost(i)
     local q=slots[i];local dx,dz=q.x-p.x,q.z-p.z
     local cross=axis==1 and dx or axis==2 and dz or axis==3 and dx+dz or axis==4 and dx-dz or 0
     return distance[first][i]+cross*cross*.8
    end
    table.sort(indices,function(i,j)local a,b=Cost(i),Cost(j);return a~=b and a<b or a==b and i<j end)
    while #indices>size+2 do indices[#indices]=nil end
    table.sort(indices);local signature=size..':'..table.concat(indices,',')
    if not pools[signature] then
     pools[signature]=true;local group={first}
     local function Generate(at)
      if Limited() then return end
      if #group==size then Add(group);return end
      for j=at,#indices-(size-#group)+1 do
       group[#group+1]=indices[j];Generate(j+1);group[#group]=nil
      end
     end
     Generate(1)
    end
   end
  end end
  table.sort(candidates,function(a,b)return a.score~=b.score and a.score<b.score or a.score==b.score and a.key<b.key end)
  for _,candidate in ipairs(candidates) do
   for _,i in ipairs(candidate.group) do active[i]=false end
   counts[candidate.size]=counts[candidate.size]-1;solution[#solution+1]=candidate
   if Search(left-1,blanks) then return true end
   solution[#solution]=nil;counts[candidate.size]=counts[candidate.size]+1
   for _,i in ipairs(candidate.group) do active[i]=true end
   if Limited() then break end
  end
  if blanks>0 then active[first]=false;local ok=Search(left,blanks-1);active[first]=true;if ok then return true end end
  memo[key]=true;return false
 end
 if not Search(#pieces,#slots-total) then return nil,{mode='family-cover',nodes=nodes,trials=trials,limited=Limited()} end
 local board=Empty(#slots);local assigned={}
 for _,piece in ipairs(pieces) do
  for j,candidate in ipairs(solution) do if not assigned[j] and candidate.size==piece.size then
   for _,i in ipairs(candidate.group) do board[i]=piece.k end
   assigned[j]=true;break
  end end
 end
 return board,{mode='family-cover',nodes=nodes,trials=trials}
end
return M
