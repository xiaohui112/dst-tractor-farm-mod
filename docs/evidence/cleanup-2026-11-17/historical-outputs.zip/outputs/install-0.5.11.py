from pathlib import Path
from zipfile import ZipFile
from datetime import datetime
from zoneinfo import ZoneInfo
import hashlib
import json
import os
import re
import shutil
import sys
import tempfile

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'tools'))
from package_mod import verify_archive

archive=ROOT/'Tractor.zip'
checks=json.loads((ROOT/'outputs/selfcheck-validation.json').read_text())
assert checks['mode']=='release' and checks['success'] and not checks['failures'] and not checks['warnings']
assert len(checks['checks'])==17 and all(c['status']=='passed' for c in checks['checks'])
manifest=verify_archive(ROOT/'mod/Tractor',archive)
archive_hash=hashlib.sha256(archive.read_bytes()).hexdigest()
assert archive_hash==json.loads((ROOT/'outputs/install-validation.json').read_text())['sha256']
mods=Path("/Users/tal/Library/Application Support/Steam/steamapps/common/Don't Starve Together/dontstarve_steam.app/Contents/mods")
target=mods/'Tractor'
assert target.is_dir() and not target.is_symlink()
owner=target.stat()
old_version=re.search(r'^version\s*=\s*"([^"]+)"',(target/'modinfo.lua').read_text(),re.M).group(1)
stamp=datetime.now(ZoneInfo('Asia/Shanghai')).strftime('%Y%m%d-%H%M%S-%f')
backup=ROOT/'outputs/game-mod-backups'/stamp/'Tractor'
backup.parent.mkdir(parents=True)
stage_parent=Path(tempfile.mkdtemp(prefix='.tractor-install-',dir=mods))
stage=stage_parent/'Tractor'

def verify(folder):
    files={p.relative_to(folder).as_posix():p for p in folder.rglob('*') if p.is_file()}
    assert set(files)==set(manifest['files'])|{'INSTALL-MANIFEST.json'}
    assert json.loads(files['INSTALL-MANIFEST.json'].read_text())==manifest
    for name,entry in manifest['files'].items():
        raw=files[name].read_bytes()
        assert len(raw)==entry['bytes'] and hashlib.sha256(raw).hexdigest()==entry['sha256'],name
    assert re.search(r'^version\s*=\s*"0\.5\.11"',files['modinfo.lua'].read_text(),re.M)

backed_up=False
installed=False
try:
    with ZipFile(archive) as z:z.extractall(stage_parent)
    verify(stage)
    if os.geteuid()==0:
        for path in [stage,*stage.rglob('*')]:os.chown(path,owner.st_uid,owner.st_gid)
    target.rename(backup)
    backed_up=True
    stage.rename(target)
    installed=True
    verify(target)
except Exception:
    if installed:shutil.rmtree(target)
    if backed_up:backup.rename(target)
    raise
finally:
    shutil.rmtree(stage_parent)

report={'installed_at':datetime.now(ZoneInfo('Asia/Shanghai')).isoformat(),'version':'0.5.11','previous_version':old_version,
        'target':str(target),'backup':str(backup),'archive_sha256':archive_hash,'source_files':len(manifest['files']),
        'all_installed_bytes_match':True,'installed_manifest_matches':True,'game_restarted':False,'save_files_modified':False}
(ROOT/'outputs/game-install-validation.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
