"""直接安装工作区运行文件；不生成ZIP，不修改版本，先验证暂存再保留旧安装。"""
import hashlib
import json
import os
from pathlib import Path
import shutil
import sys
import tempfile
from datetime import datetime
from zoneinfo import ZoneInfo

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'tools'))
from package_mod import source_files

SOURCE = ROOT / 'mod/Tractor'
TARGET = Path.home() / "Library/Application Support/Steam/steamapps/common/Don't Starve Together/dontstarve_steam.app/Contents/mods/Tractor"
STAMP = datetime.now(ZoneInfo('Asia/Shanghai')).strftime('%Y%m%d-%H%M%S-%f')
BACKUP = ROOT / 'outputs/game-mod-backups' / STAMP / 'Tractor'
REPORT = ROOT / 'outputs' / ('workspace-direct-install-' + STAMP + '.json')


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def all_files(folder):
    return {p.relative_to(folder).as_posix(): digest(p)
            for p in sorted(folder.rglob('*')) if p.is_file()}


def verify(folder, files, manifest_bytes):
    expected = {name: row['sha256'] for name, row in files.items()}
    expected['INSTALL-MANIFEST.json'] = hashlib.sha256(manifest_bytes).hexdigest()
    if all_files(folder) != expected:
        raise RuntimeError('Installed/staged files differ from workspace manifest')


def main():
    if not TARGET.is_dir() or TARGET.is_symlink():
        raise RuntimeError('Expected an existing regular Tractor installation')
    archive_hash = digest(ROOT / 'Tractor.zip')
    version_bytes = (SOURCE / 'modinfo.lua').read_bytes()
    sources = source_files(SOURCE)
    if 'INSTALL-MANIFEST.json' in sources:
        raise RuntimeError('Unexpected source install manifest')
    files = {name: {'sha256': digest(path), 'bytes': path.stat().st_size}
             for name, path in sources.items()}
    previous = all_files(TARGET)
    BACKUP.parent.mkdir(parents=True)
    if TARGET.stat().st_dev != BACKUP.parent.stat().st_dev:
        raise RuntimeError('Backup and target must share a filesystem for atomic moves')
    manifest = {'schema': 1, 'install_mode': 'workspace-direct',
                'installed_at': datetime.now(ZoneInfo('Asia/Shanghai')).isoformat(),
                'version': '0.5.8', 'files': files}
    raw = (json.dumps(manifest, ensure_ascii=False, sort_keys=True, indent=2) + '\n').encode()
    moved = installed = False
    with tempfile.TemporaryDirectory(prefix='.Tractor-workspace-', dir=TARGET.parent.parent) as temp:
        stage = Path(temp) / 'Tractor'
        stage.mkdir()
        for name, path in sources.items():
            dest = stage / name
            dest.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(path, dest)
        (stage / 'INSTALL-MANIFEST.json').write_bytes(raw)
        verify(stage, files, raw)
        if (SOURCE / 'modinfo.lua').read_bytes() != version_bytes:
            raise RuntimeError('Source version changed while staging')
        if any(digest(path) != files[name]['sha256'] for name, path in sources.items()):
            raise RuntimeError('Source changed while staging')
        try:
            os.replace(TARGET, BACKUP)
            moved = True
            if all_files(BACKUP) != previous:
                raise RuntimeError('Backup validation failed')
            os.replace(stage, TARGET)
            installed = True
            verify(TARGET, files, raw)
            if digest(ROOT / 'Tractor.zip') != archive_hash:
                raise RuntimeError('Release ZIP unexpectedly changed')
            if (SOURCE / 'modinfo.lua').read_bytes() != version_bytes:
                raise RuntimeError('Source version unexpectedly changed')
        except BaseException:
            if installed and TARGET.exists():
                shutil.rmtree(TARGET)
            if moved:
                os.replace(BACKUP, TARGET)
            raise
    result = {'status': 'passed', 'mode': 'workspace-direct', 'version': '0.5.8',
              'runtime_file_count': len(files), 'target': str(TARGET), 'backup': str(BACKUP),
              'release_zip_unchanged': True, 'release_zip_sha256': archive_hash,
              'modinfo_unchanged': True, 'all_installed_hashes_match': True,
              'manifest': manifest}
    REPORT.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({k: v for k, v in result.items() if k != 'manifest'}, ensure_ascii=False, indent=2))
    print('validation_report:', REPORT)


if __name__ == '__main__':
    main()
