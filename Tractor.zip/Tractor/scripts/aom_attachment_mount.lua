-- 独立世界挂点：配件始终是实体，不进入仓库或玩家背包。
local M={RANGE=5}
local PREFABS={aom_landclearer=true,aom_plow=true,aom_seeder=true,aom_irrigator=true,
    aom_fertilizer=true,aom_weeder=true,aom_harvester=true}
function M.IsRecord(record)return record and PREFABS[record.prefab]==true end
function M.Get(vehicle)
    if vehicle.GetAttachment then return vehicle:GetAttachment() end
    -- 兼容旧载体/外部工具调用；新版底盘始终提供独立 GetAttachment。
    local c=vehicle.components.container
    return c and c:GetItemInSlot(1) or nil
end
function M.Owner(item)
    return item._aom_vehicle and item._aom_vehicle:value() or nil
end
function M.CanReach(doer,item)
    local distance=M.RANGE+doer:GetPhysicsRadius(0)+item:GetPhysicsRadius(0)
    return doer:GetDistanceSqToInst(item)<=distance*distance
end
local function Source(vehicle)
    return vehicle._rider or vehicle
end
function M.FreePosition(vehicle,item)
    local source=Source(vehicle)
    local x,y,z=source.Transform:GetWorldPosition()
    for _,radius in ipairs({3,4,5,6,8,10,14,18}) do
        for i=0,15 do
            local a=i*math.pi/8
            local px,pz=x+radius*math.cos(a),z+radius*math.sin(a)
            if TheWorld.Map:IsPassableAtPoint(px,0,pz) then
                local free=true
                for _,v in ipairs(TheSim:FindEntities(px,0,pz,.8,nil,{"INLIMBO","NOCLICK","FX","NOBLOCK"})) do
                    if v~=vehicle and v~=source and v~=item and v.prefab~="farm_soil"
                        and not v.components.inventoryitem then free=false;break end
                end
                if free then return Vector3(px,0,pz) end
            end
        end
    end
end
function M.Sync(vehicle)
    local item=vehicle._aom_attachment
    if item and not item:IsValid() then item=nil;vehicle._aom_attachment=nil end
    vehicle._attachment_type=item and item.attachment_type or nil
    if vehicle._attachment then vehicle._attachment:set(item) end
    if vehicle._atttype_net then vehicle._atttype_net:set(vehicle._attachment_type or "") end
    vehicle:PushEvent("aom_attachment_changed")
end
function M.Detach(vehicle,doer,force)
    local item=vehicle._aom_attachment
    if not item then return false end
    local pos=M.FreePosition(vehicle,item)
    if not pos and force then pos=Vector3(Source(vehicle).Transform:GetWorldPosition()) end
    if not pos then return false end -- 无安全落点时保留损坏设备，不能丢失物品。
    require("aom_drive").SetWorking(vehicle,false)
    vehicle._aom_attachment=nil
    if item._aom_vehicle then item._aom_vehicle:set(nil) end
    item.persists=true
    item:RemoveTag("NOBLOCK")
    if item.Physics then item.Physics:SetActive(true) end
    item.Transform:SetPosition(pos:Get())
    M.Sync(vehicle)
    return true
end
function M.Attach(vehicle,doer,item)
    if vehicle._destroyed or vehicle.components.health and vehicle.components.health:IsDead()
        or not item or not item:IsValid() or not item:HasTag("aom_attachment")
        or M.Owner(item) or vehicle._aom_attachment then return false end
    if require("aom_durability").GetUses(item)<=0 then return false end
    if doer then
        local rider=doer.components.rider
        if not rider or not rider:IsRiding() or rider:GetMount()~=vehicle or vehicle._rider~=doer
            or not M.CanReach(doer,item) then return false end
    end
    local ii=item.components.inventoryitem
    if ii and ii.owner then ii:RemoveFromOwner(true) end
    vehicle._aom_attachment=item
    item._aom_vehicle:set(vehicle)
    item.persists=false -- 随拖拉机的独立存档记录保存，避免世界里重复加载。
    item:AddTag("NOBLOCK")
    if item.Physics then item.Physics:SetActive(false) end
    require("aom_drive").SetWorking(vehicle,false)
    M.Sync(vehicle)
    M.UpdateVisual(item)
    return true
end
function M.UpdateVisual(item)
    local vehicle=M.Owner(item)
    if vehicle and not vehicle:IsValid() then vehicle=nil end
    if vehicle~=item._aom_visual_vehicle then
        item._aom_visual_vehicle=vehicle
        if item.Physics then item.Physics:SetActive(vehicle==nil) end
    end
    if not vehicle then
        require("aom_attachment_animation").Update(item,nil)
        return
    end
    local rider=vehicle._rider_net and vehicle._rider_net:value()
    local source=rider and rider:IsValid() and rider or vehicle
    local x,y,z=source.Transform:GetWorldPosition()
    local rotation=source.Transform:GetRotation()
    local distance=require("aom_model_scale")*1.4*(item.attachment_type=="harvester" and 1 or -1)
    local angle=rotation*math.pi/180
    item.Transform:SetPosition(x+distance*math.cos(angle),y,z-distance*math.sin(angle))
    item.Transform:SetRotation(rotation)
    require("aom_attachment_animation").Update(item,vehicle)
end
function M.Restore(vehicle,record)
    if not record then return end
    local item=SpawnSaveRecord(record)
    if item and not M.Attach(vehicle,nil,item) then
        local pos=M.FreePosition(vehicle,item) or Source(vehicle):GetPosition()
        item.Transform:SetPosition(pos:Get())
    end
end
return M
