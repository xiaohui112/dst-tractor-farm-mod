-- Pending Windows build.
return { available=false, bank="aom_tractor_driver", build="aom_tractor_cabin" }
